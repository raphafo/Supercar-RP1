<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    // Redirige vers la page de connexion si non connecté
    header("Location: connexion.php");
    exit;
}
?>

<?php
require_once 'db_connexion.php'; // crée $pdo (instance PDO)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"] ?? null;
    $prenom = $_POST["prenom"] ?? null;
    $email = $_POST["email"] ?? null;
    $lieurecup = $_POST["lieurecup"] ?? null;
    $lieudepot = $_POST["lieudepot"] ?? null;
    $daterecup = $_POST["daterecup"] ?? null;
    $datedepot = $_POST["datedepot"] ?? null;
    $heurerecup = $_POST["heurerecup"] ?? null;

    if (!$nom || !$prenom || !$email) {
        die("Erreur : tous les champs requis ne sont pas remplis !");
    }

    try {
        // 1️⃣ Préparer la requête d’insertion
        $sql = "INSERT INTO essai (nom, prenom, email, lieurecup, lieudepot, daterecup, datedepot, heurerecup) 
                VALUES (:nom, :prenom, :email, :lieurecup, :lieudepot, :daterecup, :datedepot, :heurerecup)";
        
        $stmt = $pdo->prepare($sql);

        // 2️⃣ Lier les valeurs
        $stmt->bindValue(':nom', $nom, PDO::PARAM_STR);
        $stmt->bindValue(':prenom', $prenom, PDO::PARAM_STR);
        $stmt->bindValue(':email', $email, PDO::PARAM_STR);
        $stmt->bindValue(':lieurecup', $lieurecup, PDO::PARAM_STR);
        $stmt->bindValue(':lieudepot', $lieudepot, PDO::PARAM_STR);
        $stmt->bindValue(':daterecup', $daterecup, PDO::PARAM_STR);
        $stmt->bindValue(':datedepot', $datedepot, PDO::PARAM_STR);
        $stmt->bindValue(':heurerecup', $heurerecup, PDO::PARAM_STR);

        // 3️⃣ Exécuter
        $stmt->execute();

        // 4️⃣ Récupérer l’ID inséré
        $id_essai = $pdo->lastInsertId();

        // 5️⃣ Appeler la procédure stockée
        $pdo->query("CALL notifier_nouvelle_demande($id_essai)");

        echo "Demande enregistrée avec succès ! <a href='index.html'>Retour à la page d'accueil</a>";

    } catch (PDOException $e) {
        echo "Erreur SQL : " . $e->getMessage();
    }

} else {
    echo "Accès interdit.";
}



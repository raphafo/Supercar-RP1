<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

require_once '../db_connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $id = intval($_POST['booking_id']);
    
    try {
        $stmt = $pdo->prepare("UPDATE essai SET statut = 'Refusé' WHERE id = ?");
        $stmt->execute([$id]);
        
        $_SESSION['success_message'] = "Demande d'essai refusée.";
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Erreur lors du refus: " . $e->getMessage();
    }
} else {
    $_SESSION['error_message'] = "Requête invalide.";
}

header("Location: dashadmin.php#bookings-section");
exit();
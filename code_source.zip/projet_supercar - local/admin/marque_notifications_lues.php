<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") exit;

require_once '../db_connexion.php';

$stmt = $pdo->prepare("UPDATE notifications SET vu = 1 WHERE vu = 0");
$stmt->execute();
?>
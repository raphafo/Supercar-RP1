<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

require_once '../db_connexion.php';

// AJOUTER
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ajouter'])) {
    $titre = $_POST['titre'];
    $description = $_POST['description'];

    try {
        $stmt = $pdo->prepare("INSERT INTO conseils (titre, description) VALUES (?, ?)");
        $stmt->execute([$titre, $description]);

        header("Location: conseils_admin.php?msg=added");
        exit;
    } catch (PDOException $e) {
        die("Erreur lors de l'ajout: " . $e->getMessage());
    }
}

// MODIFIER
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['modifier'])) {
    $id = intval($_POST['id']);
    $titre = $_POST['titre'];
    $description = $_POST['description'];

    try {
        $stmt = $pdo->prepare("UPDATE conseils SET titre=?, description=? WHERE id=?");
        $stmt->execute([$titre, $description, $id]);

        header("Location: conseils_admin.php?msg=updated");
        exit;
    } catch (PDOException $e) {
        die("Erreur lors de la modification: " . $e->getMessage());
    }
}

// SUPPRIMER
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    try {
        $stmt = $pdo->prepare("DELETE FROM conseils WHERE id = ?");
        $stmt->execute([$id]);
        
        header("Location: conseils_admin.php?msg=deleted");
        exit;
    } catch (PDOException $e) {
        die("Erreur lors de la suppression: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Conseils</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Gestion des Conseils et Expertises</h2>

    <!-- Formulaire ajout -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Ajouter un conseil</div>
        <div class="card-body">
            <form method="post">
                <input type="text" name="titre" placeholder="Titre du conseil" required class="form-control mb-2">
                <textarea name="description" placeholder="Description du conseil" required class="form-control mb-2"></textarea>
                <button type="submit" name="ajouter" class="btn btn-success">Ajouter</button>
            </form>
        </div>
    </div>

    <!-- Tableau -->
    <div class="card">
        <div class="card-header bg-dark text-white">Liste des conseils</div>
        <div class="card-body">
            <table class="table table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Titre</th>
                        <th>Description</th>
                        <th width="200">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $res = $pdo->query("SELECT * FROM conseils ORDER BY id DESC");
                while ($row = $res->fetch(PDO::FETCH_ASSOC)):
                ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['titre']) ?></td>
                        <td><?= nl2br(htmlspecialchars($row['contenu'])) ?></td>
                        <td>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#editModal<?= $row['id'] ?>">Modifier</button>
                            <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger"
                               onclick="return confirm('Supprimer ce conseil ?')">Supprimer</a>
                        </td>
                    </tr>

                    <!-- Modal édition -->
                    <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form method="post">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Modifier conseil #<?= $row['id'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <div class="mb-3">
                                            <label>Titre</label>
                                            <input type="text" name="titre" class="form-control"
                                                   value="<?= htmlspecialchars($row['titre']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label>Description</label>
                                            <textarea name="contenu" class="form-control" required><?= htmlspecialchars($row['contenu']) ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" name="modifier" class="btn btn-success">Enregistrer</button>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

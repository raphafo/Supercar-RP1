<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    exit("unauthorized");
}

require_once '../db_connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'] ?? '';
    $icone = $_POST['icone'] ?? 'fas fa-car'; // icône par défaut
    $description = $_POST['description'] ?? '';
    $lien = $_POST['lien'] ?? '';
    $type = $_POST['type'] ?? 'texte';
    $details = $_POST['details'] ?? '';

    try {
        $stmt = $pdo->prepare("INSERT INTO services (titre, icone, description, lien, type, details) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$titre, $icone, $description, $lien, $type, $details]);
        
        header("Location: services.php?msg=added");
        exit;
    } catch (PDOException $e) {
        echo "error: " . $e->getMessage();
    }
}

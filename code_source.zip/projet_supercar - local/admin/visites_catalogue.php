<?php
session_start();
require_once __DIR__ . '/../db_connexion.php';

// Récupérer les 200 dernières visites
$limit = 200;
$stmt = $pdo->prepare('
    SELECT id, ip, user_agent, visit_time
    FROM visites_catalogue
    ORDER BY visit_time DESC
    LIMIT :lim
');
$stmt->bindValue(':lim', (int)$limit, PDO::PARAM_INT);
$stmt->execute();
$visites = $stmt->fetchAll();

// Nombre total de visites
$total = $pdo->query('SELECT COUNT(*) FROM visites_catalogue')->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Visites Catalogue - Admin</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body class="p-4">
<div class="container">
    <h1 class="mb-3">Visites du catalogue</h1>

    <p>Total des visites enregistrées : <strong><?= htmlspecialchars($total) ?></strong></p>
    <p>Affichage des <?= htmlspecialchars($limit) ?> dernières visites.</p>

    <a class="btn btn-secondary mb-3" href="dashadmin.php">← Retour au tableau de bord</a>

    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Adresse IP</th>
                    <th>Date et heure</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($visites as $v): ?>
                <tr>
                    <td><?= $v['id'] ?></td>
                    <td style="max-width:400px; overflow-wrap:anywhere"><?= htmlspecialchars($v['user_agent']) ?></td>
                    <td><?= htmlspecialchars($v['visit_time']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>


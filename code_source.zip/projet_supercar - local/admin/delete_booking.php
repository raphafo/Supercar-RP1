<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

require_once '../db_connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $id = intval($_POST['booking_id']);
    
    try {
        $stmt = $pdo->prepare("DELETE FROM essai WHERE id = ?");
        $stmt->execute([$id]);
        
        $_SESSION['success_message'] = "Demande d'essai supprimée avec succès.";
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Erreur lors de la suppression: " . $e->getMessage();
    }
}

header("Location: dashadmin.php#bookings-section");
exit();
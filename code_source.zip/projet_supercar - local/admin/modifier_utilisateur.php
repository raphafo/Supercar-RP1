<?php
session_start(); // Toujours en haut

// Connexion à la base de données (PDO)
require_once '../db_connexion.php';

$message = '';
$messageType = '';
$user = null;

// Récupérer l'ID de l'utilisateur
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id <= 0) {
    $_SESSION['error_message'] = 'ID utilisateur invalide.';
    header('Location: dashadmin.php');
    exit;
}

try {
    // Récupérer les informations de l'utilisateur
    $stmt = $pdo->prepare("SELECT * FROM inscription WHERE id = ?");
    $stmt->execute([$user_id]);
    
    if ($stmt->rowCount() == 0) {
        $_SESSION['error_message'] = 'Utilisateur non trouvé.';
        header('Location: dashadmin.php');
        exit;
    }
    
    $user = $stmt->fetch();
    
    // Traitement du formulaire
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $ville = trim($_POST['ville'] ?? '');
        $nouveau_password = $_POST['nouveau_password'] ?? '';
        $actif = isset($_POST['actif']) ? 1 : 0;
        $role = $_POST['role'] ?? 'user';
        
        // Validation des champs
        if (empty($nom) || empty($prenom) || empty($email)) {
            $message = 'Les champs nom, prénom et email sont obligatoires.';
            $messageType = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'L\'adresse email n\'est pas valide.';
            $messageType = 'error';
        } elseif (!empty($nouveau_password) && strlen($nouveau_password) < 6) {
            $message = 'Le nouveau mot de passe doit contenir au moins 6 caractères.';
            $messageType = 'error';
        } else {
            // Vérifier si l'email existe déjà pour un autre utilisateur
            $check_stmt = $pdo->prepare("SELECT id FROM inscription WHERE email = ? AND id != ?");
            $check_stmt->execute([$email, $user_id]);
            
            if ($check_stmt->rowCount() > 0) {
                $message = 'Cet email est déjà utilisé par un autre utilisateur.';
                $messageType = 'error';
            } else {
                // Construire la requête selon si on change le mot de passe ou non
                if (!empty($nouveau_password)) {
                    $hashed_password = password_hash($nouveau_password, PASSWORD_DEFAULT);
                    $update_stmt = $pdo->prepare("UPDATE inscription SET nom = ?, prenom = ?, email = ?, ville = ?, password = ?, actif = ?, role = ? WHERE id = ?");
                    $update_stmt->execute([$nom, $prenom, $email, $ville, $hashed_password, $actif, $role, $user_id]);
                } else {
                    $update_stmt = $pdo->prepare("UPDATE inscription SET nom = ?, prenom = ?, email = ?, ville = ?, actif = ?, role = ? WHERE id = ?");
                    $update_stmt->execute([$nom, $prenom, $email, $ville, $actif, $role, $user_id]);
                }
                
                if ($update_stmt->rowCount() > 0) {
                    $_SESSION['success_message'] = 'Utilisateur modifié avec succès !';
                    header('Location: dashadmin.php');
                    exit;
                } else {
                    $message = 'Aucune modification n\'a été effectuée.';
                    $messageType = 'warning';
                }
            }
        }
        
        // Mettre à jour les données de l'utilisateur avec les valeurs du formulaire
        $user['nom'] = $nom;
        $user['prenom'] = $prenom;
        $user['email'] = $email;
        $user['ville'] = $ville;
        $user['actif'] = $actif;
        $user['role'] = $role;
    }
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier l'Utilisateur - SuperCar Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .card-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .card-header p {
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .card-body {
            padding: 40px;
        }

        .user-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid #f39c12;
        }

        .user-info h4 {
            color: #333;
            margin-bottom: 5px;
        }

        .user-info p {
            color: #666;
            font-size: 0.9rem;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 0.95rem;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #f39c12;
            box-shadow: 0 0 0 3px rgba(243, 156, 18, 0.1);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            margin: 0;
            transform: scale(1.2);
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-right: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(243, 156, 18, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert-warning {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .container {
                margin: 20px auto;
                padding: 0 15px;
            }
            
            .card-body {
                padding: 25px;
            }
        }

        .required {
            color: #dc3545;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #f39c12;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #e67e22;
        }

        .password-note {
            font-size: 0.85rem;
            color: #666;
            font-style: italic;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashadmin.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
            Retour au tableau de bord
        </a>

        <div class="card">
            <div class="card-header">
                <h1><i class="fas fa-user-edit"></i> Modifier l'Utilisateur</h1>
                <p>Modifier les informations de l'utilisateur</p>
            </div>

            <div class="card-body">
                <div class="user-info">
                    <h4>Utilisateur #<?= str_pad($user['id'], 3, '0', STR_PAD_LEFT) ?></h4>
                    <p>Inscrit le : <?= date('d/m/Y à H:i', strtotime($user['date_inscription'] ?? 'now')) ?></p>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType ?>">
                        <i class="fas fa-<?= $messageType == 'error' ? 'exclamation-triangle' : ($messageType == 'warning' ? 'exclamation-circle' : 'check-circle') ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="nom">
                                Nom <span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="nom" 
                                   name="nom" 
                                   value="<?= htmlspecialchars($user['nom']) ?>" 
                                   required
                                   placeholder="Nom de famille">
                        </div>

                        <div class="form-group">
                            <label for="prenom">
                                Prénom <span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="prenom" 
                                   name="prenom" 
                                   value="<?= htmlspecialchars($user['prenom']) ?>" 
                                   required
                                   placeholder="Prénom">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">
                            Email <span class="required">*</span>
                        </label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               value="<?= htmlspecialchars($user['email']) ?>" 
                               required
                               placeholder="exemple@email.com">
                    </div>

                    <div class="form-group">
                        <label for="ville">
                            Ville
                        </label>
                        <input type="text" 
                               id="ville" 
                               name="ville" 
                               value="<?= htmlspecialchars($user['ville'] ?? '') ?>"
                               placeholder="Ville de résidence">
                    </div>

                    <div class="form-group">
                        <label for="nouveau_password">
                            Nouveau mot de passe
                        </label>
                        <input type="password" 
                               id="nouveau_password" 
                               name="nouveau_password" 
                               minlength="6"
                               placeholder="Laisser vide pour ne pas changer">
                        <div class="password-note">
                            Laissez ce champ vide si vous ne souhaitez pas changer le mot de passe
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="role">
                            Rôle
                        </label>
                        <select id="role" name="role" class="form-control">
                            <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>Utilisateur</option>
                            <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Administrateur</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" 
                                   id="actif" 
                                   name="actif" 
                                   <?= $user['actif'] ? 'checked' : '' ?>>
                            <label for="actif">Compte actif</label>
                        </div>
                    </div>

                    <div style="margin-top: 30px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            Enregistrer les modifications
                        </button>
                        
                        <a href="dashadmin.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i>
                            Annuler
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Validation côté client
        document.querySelector('form').addEventListener('submit', function(e) {
            const password = document.getElementById('nouveau_password').value;
            const email = document.getElementById('email').value;
            
            if (password && password.length < 6) {
                e.preventDefault();
                alert('Le nouveau mot de passe doit contenir au moins 6 caractères.');
                return;
            }
            
            if (!email.includes('@')) {
                e.preventDefault();
                alert('Veuillez saisir une adresse email valide.');
                return;
            }
        });
    </script>
</body>
</html>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin SuperCar - Gestion Accueil</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #247eec;
            --secondary: #12906c;
            --dark: #343a40;
            --light: #f8f9fa;
        }
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 15px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .sidebar a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        .card-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-radius: 10px 10px 0 0 !important;
            font-weight: 600;
        }
        .btn-primary {
            background: var(--primary);
            border: none;
        }
        .btn-primary:hover {
            background: #1c6bc9;
        }
        .navbar-brand {
            font-weight: 700;
            color: var(--primary);
        }
        .preview-box {
            border: 1px dashed #ccc;
            padding: 15px;
            border-radius: 5px;
            background: #f9f9f9;
            margin-top: 10px;
        }
        .logo-preview {
            max-width: 200px;
            max-height: 100px;
            margin: 10px 0;
        }
        .video-preview {
            width: 100%;
            height: 200px;
            background: #eee;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar d-none d-md-block">
                <h4 class="text-center mb-4">Admin SuperCar</h4>
                <a href="#" class="active"><i class="fas fa-home"></i> Accueil</a>
                <a href="#"><i class="fas fa-car"></i> Catalogue</a>
                <a href="#"><i class="fas fa-clipboard-list"></i> Demandes</a>
                <a href="#"><i class="fas fa-concierge-bell"></i> Services</a>
                <a href="#"><i class="fas fa-users"></i> Utilisateurs</a>
                <a href="#"><i class="fas fa-cog"></i> Paramètres</a>
                <a href="#"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Gestion de la Page d'Accueil</h2>
                    <button class="btn btn-primary"><i class="fas fa-eye me-2"></i>Prévisualiser</button>
                </div>

                <!-- Formulaire de gestion de la bannière -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-video me-2"></i>Bannière Vidéo
                    </div>
                    <div class="card-body">
                        <form id="bannerForm">
                            <div class="mb-3">
                                <label class="form-label">Vidéo de fond</label>
                                <input type="file" class="form-control" accept="video/mp4">
                                <small class="form-text text-muted">Format recommandé: MP4, résolution 1080p</small>
                                <div class="video-preview">
                                    <i class="fas fa-video fa-3x text-muted"></i>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Titre principal</label>
                                <input type="text" class="form-control" value="Un moyen rapide et facile d'acheter une voiture">
                            </div>
                            <button type="submit" class="btn btn-primary">Enregistrer</button>
                        </form>
                    </div>
                </div>

                <!-- Formulaire de gestion de la section À propos -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-info-circle me-2"></i>Section "À propos"
                    </div>
                    <div class="card-body">
                        <form id="aboutForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Logo</label>
                                        <input type="file" class="form-control" accept="image/*">
                                        <small class="form-text text-muted">Format recommandé: PNG avec fond transparent</small>
                                        <div class="text-center">
                                            <img src="https://via.placeholder.com/200x100" class="logo-preview">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Titre</label>
                                        <input type="text" class="form-control" value="À propos de nous">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Description</label>
                                        <textarea class="form-control" rows="5">Votre solution premium pour la location de voitures de luxe et de haute performance. Découvrez notre sélection exclusive de BMW, Mercedes et Toyota, soigneusement entretenues et prêtes à vous offrir une expérience de conduite inoubliable.

Chez SuperCar, nous transformons vos déplacements en moments d'exception, alliant confort, élégance et technologie de pointe.</textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Texte du bouton</label>
                                        <input type="text" class="form-control" value="Rechercher un véhicule">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Enregistrer</button>
                        </form>
                    </div>
                </div>

                <!-- Formulaire de gestion du pied de page -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-shoe-prints me-2"></i>Pied de Page
                    </div>
                    <div class="card-body">
                        <form id="footerForm">
                            <div class="mb-3">
                                <label class="form-label">Texte de copyright</label>
                                <input type="text" class="form-control" value="&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Liens</label>
                                <div class="row">
                                    <div class="col-md-4">
                                        <input type="text" class="form-control mb-2" value="Contact" placeholder="Texte du lien">
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control mb-2" value="contact.html" placeholder="URL du lien">
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control mb-2" value="Confidentialité" placeholder="Texte du lien">
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control mb-2" value="#" placeholder="URL du lien">
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control mb-2" value="Mentions légales" placeholder="Texte du lien">
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control mb-2" value="#" placeholder="URL du lien">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Enregistrer</button>
                        </form>
                    </div>
                </div>

                <!-- Aperçu en temps réel -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-desktop me-2"></i>Aperçu de la page d'accueil
                    </div>
                    <div class="card-body">
                        <div class="preview-box">
                            <h4>Bannière</h4>
                            <p>Titre: <strong>Un moyen rapide et facile d'acheter une voiture</strong></p>
                            
                            <h4>À propos</h4>
                            <p>Titre: <strong>À propos de nous</strong></p>
                            <p>Description: <em>Votre solution premium pour la location de voitures de luxe et de haute performance...</em></p>
                            <p>Bouton: <span class="badge bg-primary">Rechercher un véhicule</span></p>
                            
                            <h4>Pied de page</h4>
                            <p>Copyright: <strong>&copy; SUPERCAR 2024-2026 | By Student MCCI | SIO</strong></p>
                            <p>Liens: 
                                <a href="#" class="me-3">Contact</a>
                                <a href="#" class="me-3">Confidentialité</a>
                                <a href="#" class="me-3">Mentions légales</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Simulation de l'enregistrement des données
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                alert('Modifications enregistrées avec succès!');
            });
        });

        // Gestion de l'aperçu des images
        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', function(e) {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    const previewElement = this.closest('.mb-3').querySelector('img') || 
                                          this.closest('.mb-3').querySelector('.video-preview');
                    
                    reader.onload = function(e) {
                        if (previewElement.tagName === 'IMG') {
                            previewElement.src = e.target.result;
                        } else {
                            previewElement.innerHTML = `
                                <video width="100%" height="100%" controls>
                                    <source src="${e.target.result}" type="video/mp4">
                                    Votre navigateur ne supporte pas la vidéo.
                                </video>
                            `;
                        }
                    }
                    
                    reader.readAsDataURL(this.files[0]);
                }
            });
        });
    </script>
</body>
</html>
<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    exit("unauthorized");
}

require_once '../db_connexion.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    try {
        $stmt = $pdo->prepare("DELETE FROM services WHERE id=?");
        
        if ($stmt->execute([$id])) {
            header("Location: services.php?msg=deleted");
            exit;
        } else {
            echo "error";
        }
    } catch (PDOException $e) {
        echo "error";
    }
}
?>
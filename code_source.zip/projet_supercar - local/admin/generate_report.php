<?php

require('fpdf/fpdf.php');
require_once '../db_connexion.php';

try {
    // Création du PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(0,10,iconv('UTF-8', 'windows-1252', 'Rapport SuperCar'),0,1,'C');
    $pdf->Ln(5);

    // Utilisateurs
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(0,10,iconv('UTF-8', 'windows-1252', 'Utilisateurs'),0,1);
    $pdf->SetFont('Arial','',10);
    
    $stmt = $pdo->query("SELECT nom, email, role, date_inscription FROM inscription");
    $users = $stmt->fetchAll();
    
    foreach($users as $row) {
        $txt = "{$row['nom']} - {$row['email']} - {$row['role']} - {$row['date_inscription']}";
        $pdf->Cell(0,8,iconv('UTF-8', 'windows-1252', $txt),0,1);
    }
    $pdf->Ln(5);

    // Voitures disponibles
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(0,10,iconv('UTF-8', 'windows-1252', 'Voitures disponibles'),0,1);
    $pdf->SetFont('Arial','',10);
    
    $stmt = $pdo->query("SELECT marque, annee, prix FROM voitures WHERE disponible = 1");
    $voitures_dispo = $stmt->fetchAll();
    
    foreach($voitures_dispo as $row) {
        $txt = "{$row['marque']} - {$row['annee']} - {$row['prix']} €";
        $pdf->Cell(0,8,iconv('UTF-8', 'windows-1252', $txt),0,1);
    }
    $pdf->Ln(5);

    // Voitures indisponibles
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(0,10,iconv('UTF-8', 'windows-1252', 'Voitures indisponibles'),0,1);
    $pdf->SetFont('Arial','',10);
    
    $stmt = $pdo->query("SELECT marque, annee, prix FROM voitures WHERE disponible = 0");
    $voitures_indispo = $stmt->fetchAll();
    
    foreach($voitures_indispo as $row) {
        $txt = "{$row['marque']} - {$row['annee']} - {$row['prix']} €";
        $pdf->Cell(0,8,iconv('UTF-8', 'windows-1252', $txt),0,1);
    }
    $pdf->Ln(5);

    // Demandes d'essai
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(0,10,iconv('UTF-8', 'windows-1252', "Demandes d'essai"),0,1);
    $pdf->SetFont('Arial','',10);
    
    $stmt = $pdo->query("SELECT e.id, v.marque, i.nom, e.date_demande, e.statut FROM essai e JOIN voitures v ON e.id_voiture = v.id JOIN inscription i ON e.user_id = i.id");
    $demandes = $stmt->fetchAll();
    
    foreach($demandes as $row) {
        $txt = "{$row['id']} - {$row['nom']} - {$row['marque']} - {$row['date_demande']} - {$row['statut']}";
        $pdf->Cell(0,8,iconv('UTF-8', 'windows-1252', $txt),0,1);
    }

    $pdf->Output('I', 'rapport_supercar.pdf');
    
} catch (PDOException $e) {
    die("Erreur lors de la génération du rapport: " . $e->getMessage());
}

exit;
<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

// Utilisation du fichier db_connexion.php qui est à la racine
require_once '../db_connexion.php';

try {
    // Statistiques utilisateurs
    $stmt = $pdo->query("SELECT COUNT(*) AS total FROM inscription");
    $totalUsers = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT COUNT(*) AS active FROM inscription WHERE actif = 1");
    $activeUsers = $stmt->fetch()['active'];

    // Statistiques demandes
    $stmt = $pdo->query("SELECT COUNT(*) AS demandes FROM essai");
    $totalDemandes = $stmt->fetch()['demandes'];

    $stmt = $pdo->query("SELECT COUNT(*) AS voitures FROM voitures");
    $totalVoitures = $stmt->fetch()['voitures'];

    // Demandes d'essai avec jointures
    $stmt = $pdo->query("SELECT e.id, v.marque, i.nom, e.date_demande, e.statut FROM essai e JOIN voitures v ON e.id_voiture = v.id JOIN inscription i ON e.user_id = i.id ORDER BY e.date_demande DESC");
    $demandes = $stmt->fetchAll();

    // Voitures
    $stmt = $pdo->query("SELECT * FROM voitures ORDER BY id DESC");
    $voitures = $stmt->fetchAll();

    // Utilisateurs
    $stmt = $pdo->query("SELECT * FROM inscription ORDER BY id DESC");
    $users = $stmt->fetchAll();

    // Demandes en attente
    $stmt = $pdo->query("SELECT COUNT(*) AS pending FROM essai WHERE statut = 'En attente'");
    $pendingDemandes = $stmt->fetch()['pending'];

    // Notifications récentes
    $stmt = $pdo->query("SELECT * FROM notifications ORDER BY date_notification DESC LIMIT 10");
    $notifications = $stmt->fetchAll();

    // Nombre de nouvelles notifications
    $stmt = $pdo->query("SELECT COUNT(*) AS nb FROM notifications WHERE vu = 0");
    $newNotifCount = $stmt->fetch()['nb'];

} catch (PDOException $e) {
    die("Erreur de base de données: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - SuperCar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #2c3e50;
            color: white;
            transition: all 0.3s ease;
            box-shadow: 4px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 20px;
            background: #34495e;
            border-bottom: 1px solid #34495e;
        }

        .logo {
            display: flex;
            align-items: center;
            font-size: 1.4rem;
            font-weight: bold;
            color: #3498db;
        }

        .logo i {
            margin-right: 10px;
            font-size: 1.6rem;
        }

        .user-profile {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #34495e;
        }

        .user-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 0 auto 10px;
            object-fit: cover;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-item {
            padding: 12px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
            display: flex;
            align-items: center;
        }

        .nav-item:hover {
            background: #34495e;
            border-left-color: #3498db;
        }

        .nav-item.active {
            background: #34495e;
            border-left-color: #3498db;
        }

        .nav-item i {
            margin-right: 15px;
            width: 20px;
            text-align: center;
        }

        .logout-item {
            margin-top: 50px;
            border-top: 1px solid #34495e;
            padding-top: 20px;
        }

        .logout-item a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .top-bar {
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .search-box {
            display: flex;
            align-items: center;
            background: #f8f9fa;
            border-radius: 25px;
            padding: 8px 15px;
            width: 300px;
        }

        .search-box i {
            color: #6c757d;
            margin-right: 10px;
        }

        .search-box input {
            border: none;
            background: none;
            outline: none;
            flex: 1;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            cursor: pointer;
        }

        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* Stats Cards */

           .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

         .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--card-color, #3498db), var(--card-color-light, #74b9ff));
            transition: height 0.3s ease;
        }
        .stat-card:hover::before {
            height: 100%;
            opacity: 0.1;
        }

        .stat-card.primary { --card-color: #3498db; --card-color-light: #74b9ff; }
        .stat-card.success { --card-color: #27ae60; --card-color-light: #00b894; }
        .stat-card.warning { --card-color: #f39c12; --card-color-light: #fdcb6e; }
        .stat-card.info { --card-color: #17a2b8; --card-color-light: #6c5ce7; }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            background: var(--card-color);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }

        /* Content Sections */
        .content-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f8f9fa;
        }

        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c3e50;
            display: flex;
            align-items: center;
        }

        .section-title i {
            margin-right: 10px;
            color: #3498db;
        }

        .btn {
            background: linear-gradient(45deg, #3498db, #2980b9);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            font-size: 0.9rem;
            text-decoration: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
            color: white;
            text-decoration: none;
        }

        .btn i {
            margin-right: 8px;
        }

        .btn-success {
            background: linear-gradient(45deg, #27ae60, #229954);
        }

        .btn-warning {
            background: linear-gradient(45deg, #f39c12, #d68910);
        }

        .btn-danger {
            background: linear-gradient(45deg, #e74c3c, #c0392b);
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 0.8rem;
        }

        .btn-outline-primary {
            background: transparent;
            border: 2px solid #3498db;
            color: #3498db;
        }

        .btn-outline-primary:hover {
            background: #3498db;
            color: white;
        }

        /* Tables */
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        .data-table th,
        .data-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }

        .data-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
            position: sticky;
            top: 0;
        }

        .data-table tr:hover {
            background: #f8f9fa;
        }

        .status-badge {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .status-badge:hover {
            transform: scale(1.05);
        }

        .bg-warning {
            background: #fff3cd !important;
            color: #856404 !important;
        }

        .bg-primary {
            background: #cce5ff !important;
            color: #0056b3 !important;
        }

        .bg-success {
            background: #d4edda !important;
            color: #155724 !important;
        }

        .bg-secondary {
            background: #e2e6ea !important;
            color: #383d41 !important;
        }

        .bg-danger {
            background: #a00a17ff !important;
            color: #fcfcfcff !important;
        }

        /* Modal styles (if needed for future features) */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease;
        }

        @keyframes modalSlideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .hidden {
            display: none;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
                overflow: hidden;
            }
            
            .sidebar .nav-item span {
                display: none;
            }
            
            .search-box {
                width: 200px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .section-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }

        /* Quick actions */
        .quick-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        /* Animation pour les cartes stats */
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stat-card {
            animation: slideUp 0.6s ease forwards;
        }

        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }
        .stat-card:nth-child(4) { animation-delay: 0.4s; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
                    <div class="sidebar">
                        <div class="sidebar-header">
                            <div class="logo">
                                <i class="fas fa-car"></i>
                                <span>SuperCar</span>
                            </div>
                        </div>
                        
                        <div class="user-profile">
                            <div class="user-avatar" style="background: #3498db; width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">
                                <i class="fas fa-user-shield" style="color: white; font-size: 2rem;"></i>
                            </div>
                            <div><?= $_SESSION['username'] ?? 'Admin' ?></div>
                        </div>
                        
                        <nav class="nav-menu">
                            <div class="nav-item active" onclick="showSection('dashboard')">
                                <i class="fas fa-tachometer-alt"></i>
                                <span>Tableau de bord</span>
                            </div>
                            <div class="nav-item" onclick="showSection('users')">
                                <i class="fas fa-users"></i>
                                <span>Utilisateurs</span>
                            </div>
                            <div class="nav-item" onclick="showSection('cars')">
                                <i class="fas fa-car"></i>
                                <span>Voitures</span>
                            </div>
                            <div class="nav-item" onclick="showSection('bookings')">
                                <i class="fas fa-calendar-check"></i>
                                <span>Demandes d'essai (<?= $pendingDemandes ?>)</span>
                            </div>
                            <div class="nav-item">
                            <a href="services.php" style="color:inherit;text-decoration:none;">
                            <i class="fas fa-tools service-icon"></i>
                            <span>Services</span>
                            </a>
                            </div>
                              <div class="nav-item">
                            <a href="contact.php" style="color:inherit;text-decoration:none;">
                            <i class="fas fa-phone service-icon"></i>
                            <span>Contact</span>
                            </a>
                            </div>

                            <div class="nav-item" onclick="showSection('analytics')">
                                <i class="fas fa-chart-bar"></i>
                                <span>Analytics</span>
                            </div>
                            <div class="nav-item" onclick="showSection('visites_catalogue')" >
                                    <i class="fas fa-eye" style="margin-right:15px;width:20px;text-align:center;"></i>
                                    <span>Visites Catalogue</span>
                                </a>
                            </div>
                            <div class="nav-item logout-item">
                                <a href="../logout.php">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <span>Déconnexion</span>
                                </a>
                            </div>
                        </nav>
                    </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Rechercher..." id="searchInput">
                </div>
                <div class="user-info">
                    <div class="notification-bell" onclick="toggleNotifDropdown()">
                        <i class="fas fa-bell"></i>
                        <?php if ($newNotifCount > 0): ?>
        <span class="notification-count"><?= $newNotifCount ?></span>
    <?php endif; ?>
                    </div>
                    <span>Bienvenue, <?= $_SESSION['username'] ?? 'Admin' ?></span>
                </div>
            </div>

            <!-- Dashboard Section -->
            <div id="dashboard-section" class="section">
                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card primary">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $totalUsers ?></div>
                        <div class="stat-label">Utilisateurs Inscrits</div>
                    </div>
                    
                    <div class="stat-card success">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-user-check"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $activeUsers ?></div>
                        <div class="stat-label">Utilisateurs Actifs</div>
                    </div>
                    
                    <div class="stat-card warning">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $totalDemandes ?></div>
                        <div class="stat-label">Demandes d'Essai</div>
                    </div>
                    
                    <div class="stat-card info">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-car"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $totalVoitures ?></div>
                        <div class="stat-label">Voitures Disponibles</div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-bolt"></i>
                            Actions Rapides
                        </h3>
                    </div>
                    <div class="quick-actions">
                        <a href="ajouter_voiture.php" class="btn">
                            <i class="fas fa-plus"></i> Ajouter Voiture
                        </a>
                        <a href="ajouter_utilisateur.php" class="btn btn-success">
                            <i class="fas fa-user-plus"></i> Nouvel Utilisateur
                        </a>
                        <button class="btn btn-warning" onclick="window.location.href='services.php'">
                            <i class="fas fa-file-export"></i> Gérer les Services
                        </button>
                    </div>
                </div>

                <!-- Vue d'ensemble récente -->
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-clock"></i>
                            Activité Récente
                        </h3>
                    </div>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Voiture</th>
                                    <th>Date</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
// Reset pointer for recent activity
$stmt = $pdo->query("SELECT e.id, v.marque, i.nom, e.date_demande, e.statut FROM essai e JOIN voitures v ON e.id_voiture = v.id JOIN inscription i ON e.user_id = i.id ORDER BY e.date_demande DESC LIMIT 5");
$demandes = $stmt->fetchAll();

foreach ($demandes as $row): ?>
    <tr>
        <td><?= htmlspecialchars($row['nom']) ?></td>
        <td><?= htmlspecialchars($row['marque']) ?></td>
        <td><?= htmlspecialchars($row['date_demande']) ?></td>
        <td>
            <?php
            $badgeClass = match($row['statut']) {
                'En attente' => 'bg-warning text-dark',
                'En cours' => 'bg-primary text-white',
                'Terminé' => 'bg-success text-white',
                'Refusé' => 'bg-danger text-white',
                default => 'bg-secondary text-white'
            };
            ?>
            <span class="status-badge <?= $badgeClass ?>">
                <?= htmlspecialchars($row['statut']) ?>
            </span>
        </td>
    </tr>
<?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Users Section -->
            <div id="users-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-users"></i>
                            Gestion des Utilisateurs
                        </h3>
                        <a href="ajouter_utilisateur.php" class="btn">
                            <i class="fas fa-plus"></i> Ajouter Utilisateur
                        </a>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="data-table" id="usersTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                    <th>Statut</th>
                                    <th>Date d'inscription</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php 
$stmt = $pdo->query("SELECT * FROM inscription ORDER BY id DESC");
$users = $stmt->fetchAll();

foreach ($users as $user): ?>
    <tr>
        <td><?= str_pad($user['id'], 3, '0', STR_PAD_LEFT) ?></td>
        <td><?= htmlspecialchars($user['nom']) ?></td>
        <td><?= htmlspecialchars($user['email']) ?></td>
        <td><?= htmlspecialchars($user['role']) ?></td>
        <td>
            <span class="status-badge <?= $user['actif'] ? 'bg-success text-white' : 'bg-warning text-dark' ?>">
                <?= $user['actif'] ? 'Actif' : 'Inactif' ?>
            </span>
        </td>
        <td><?= date('d/m/Y', strtotime($user['date_inscription'] ?? 'now')) ?></td>
        <td>
            <a href="modifier_utilisateur.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">
                <i class="fas fa-edit"></i>
            </a>
            <a href="supprimer_utilisateur.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression ?')">
                <i class="fas fa-trash"></i>
            </a>
        </td>
    </tr>
<?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Cars Section -->
            <div id="cars-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-car"></i>
                            Gestion des Voitures
                        </h3>
                        <a href="ajouter_voiture.php" class="btn">
                            <i class="fas fa-plus"></i> Ajouter Voiture
                        </a>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="data-table" id="carsTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Marque</th>
                                    <th>Année</th>
                                    <th>Prix</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                 $stmt = $pdo->query("SELECT * FROM voitures ORDER BY id DESC");
                                  $voitures = $stmt->fetchAll();

                              foreach ($voitures as $car): ?>
                                <tr>
                                  <td><?= str_pad($car['id'], 3, '0', STR_PAD_LEFT) ?></td>
                                   <td><?= htmlspecialchars($car['marque']) ?></td>
                                   <td><?= htmlspecialchars($car['annee']) ?></td>
                                  <td><?= number_format($car['prix'], 0, ',', ' ') ?> €</td>
                               <td><?= htmlspecialchars(substr($car['description'], 0, 50)) ?>...</td>
                                 <td>
                         <?php if ($car['image']): ?>
                              <img src="../<?= htmlspecialchars($car['image']) ?>" alt="Voiture" width="120">
            <?php else: ?>
                Pas d'image
            <?php endif; ?>
        </td>
        <td>
            <a href="modifier_voiture.php?id=<?= $car['id'] ?>" class="btn btn-sm btn-warning">
                <i class="fas fa-edit"></i>
            </a>
            <a href="supprimer_voiture.php?id=<?= $car['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression ?')">
                <i class="fas fa-trash"></i>
            </a>
        </td>
    </tr>
<?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Bookings Section -->
            <div id="bookings-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-calendar-check"></i>
                            Demandes d'Essai
                        </h3>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="data-table" id="bookingsTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Client</th>
                                    <th>Voiture</th>
                                    <th>Date demande</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
$stmt = $pdo->query("SELECT e.id, v.marque, i.nom, e.date_demande, e.statut FROM essai e JOIN voitures v ON e.id_voiture = v.id JOIN inscription i ON e.user_id = i.id ORDER BY e.date_demande DESC");
$demandes = $stmt->fetchAll();

foreach ($demandes as $row): ?>
    <tr>
        <td><?= str_pad($row['id'], 3, '0', STR_PAD_LEFT) ?></td>
        <td><?= htmlspecialchars($row['nom']) ?></td>
        <td><?= htmlspecialchars($row['marque']) ?></td>
        <td><?= htmlspecialchars($row['date_demande']) ?></td>
        <td>
            <?php
            $badgeClass = match($row['statut']) {
                'En attente' => 'bg-warning text-dark',
                'En cours' => 'bg-primary text-white',
                'Terminé' => 'bg-success text-white',
                'Refusé' => 'bg-danger text-white',
                default => 'bg-secondary text-white'
            };
            ?>
            <?php if ($row['statut'] === 'En cours'): ?>
                <form method="POST" action="changer_statut.php" style="display:inline;">
                    <input type="hidden" name="id_essai" value="<?= $row['id'] ?>">
                    <input type="hidden" name="statut_actuel" value="<?= $row['statut'] ?>">
                    <button type="submit" class="status-badge <?= $badgeClass ?>" title="Passer à Terminé">
                        <?= htmlspecialchars($row['statut']) ?>
                    </button>
                </form>
            <?php else: ?>
                <span class="status-badge <?= $badgeClass ?>">
                    <?= htmlspecialchars($row['statut']) ?>
                </span>
            <?php endif; ?>
        </td>
        <td>
            <button class="btn btn-sm btn-success" onclick="approveBooking(<?= $row['id'] ?>)">
                <i class="fas fa-check"></i>
            </button>
            <button class="btn btn-sm btn-danger" onclick="rejectBooking(<?= $row['id'] ?>)">
                <i class="fas fa-times"></i>
            </button>
            <button class="btn btn-sm btn-danger" onclick="deleteBooking(<?= $row['id'] ?>)" title="Supprimer">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    </tr>
<?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Analytics Section -->
            <div id="analytics-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-chart-bar"></i>
                            Analytics & Rapports
                        </h3>
                    </div>
                    
                    <!-- Stats détaillées -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="stat-card primary">
                                <div class="stat-header">
                                    <div class="stat-icon">
                                        <i class="fas fa-chart-line"></i>
                                    </div>
                                </div>
                                <div class="stat-value">
                                    <?php 
                                    $ratio = $activeUsers > 0 ? round(($activeUsers / $totalUsers) * 100, 1) : 0;
                                    echo $ratio . '%';
                                    ?>
                                </div>
                                <div class="stat-label">Taux d'activation utilisateurs</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stat-card warning">
                                <div class="stat-header">
                                    <div class="stat-icon">
                                        <i class="fas fa-calendar-week"></i>
                                    </div>
                                </div>
                                <div class="stat-value">
                                    <?php 
                                    $stmt = $pdo->query("SELECT COUNT(*) as count FROM essai WHERE date_demande >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
                                    $weeklyBookings = $stmt->fetch()['count'];
                                    ?>
                                </div>
                                <div class="stat-label">Demandes cette semaine</div>
                            </div>
                        </div>
                    </div>

                    <!-- Tableau de bord analytique -->
                    <div style="background: #f8f9fa; padding: 40px; border-radius: 10px; text-align: center;">
                        <i class="fas fa-chart-pie fa-3x" style="color: #6c757d; margin-bottom: 20px;"></i>
                        <h4 style="color: #6c757d;">Graphiques Analytiques</h4>
                        <p style="color: #6c757d;">Intégration avec Chart.js ou D3.js recommandée</p>
                        <div style="margin-top: 20px;">
                            <button class="btn btn-outline-primary" onclick="generateReport()">
                                <i class="fas fa-file-pdf"></i> Générer Rapport PDF
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div id="notifDropdown" class="notification-dropdown" style="display:none;position:absolute;right:0;top:40px;z-index:1000;background:white;border-radius:10px;box-shadow:0 4px 15px rgba(0,0,0,0.15);min-width:320px;">
    <div style="padding:15px 20px;border-bottom:1px solid #eee;font-weight:bold;">Notifications</div>
    <?php foreach ($notifications as $notif): ?>
        <div style="padding:12px 20px;border-bottom:1px solid #f5f5f5;<?= $notif['vu'] ? '' : 'background:#f8f9fa;font-weight:bold;' ?>">
            <i class="fas fa-info-circle" style="color:#3498db;margin-right:8px;"></i>
            <?= htmlspecialchars($notif['message']) ?>
            <span style="float:right;font-size:0.85em;color:#888;"><?= date('d/m/Y H:i', strtotime($notif['date_notification'])) ?></span>
        </div>
    <?php endforeach; ?>
    <?php if (count($notifications) == 0): ?>
        <div style="padding:15px 20px;color:#888;">Aucune notification</div>
    <?php endif; ?>
        </div>


          <!-- Section Visites Catalogue -->
<div id="visites_catalogue-section" class="section hidden">
    <div class="content-section">
        <div class="section-header">
            <h3 class="section-title">
                <i class="fas fa-eye"></i>
                Visites du Catalogue
            </h3>
        </div>
        
        <!-- Stats des visites -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card primary">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                    <div class="stat-value">
                        <?php 
                        // Total des visites du catalogue
                        $totalVisites = $pdo->query('SELECT COUNT(*) FROM visites_catalogue')->fetchColumn();
                        echo number_format($totalVisites, 0, ',', ' ');
                        ?>
                    </div>
                    <div class="stat-label">Total Visites</div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card success">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="fas fa-calendar-day"></i>
                        </div>
                    </div>
                    <div class="stat-value">
                        <?php 
                        // Visites aujourd'hui
                        $visitesToday = $pdo->query("SELECT COUNT(*) FROM visites_catalogue WHERE DATE(visit_time) = CURDATE()")->fetchColumn();
                        echo number_format($visitesToday, 0, ',', ' ');
                        ?>
                    </div>
                    <div class="stat-label">Visites Aujourd'hui</div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card warning">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="fas fa-calendar-week"></i>
                        </div>
                    </div>
                    <div class="stat-value">
                        <?php 
                        // Visites cette semaine
                        $visitesWeek = $pdo->query("SELECT COUNT(*) FROM visites_catalogue WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn();
                        echo number_format($visitesWeek, 0, ',', ' ');
                        ?>
                    </div>
                    <div class="stat-label">Cette Semaine</div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="stat-card info">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                    <div class="stat-value">
                        <?php 
                        // Visiteurs uniques (IPs différentes)
                        $uniqueVisitors = $pdo->query('SELECT COUNT(DISTINCT ip) FROM visites_catalogue')->fetchColumn();
                        echo number_format($uniqueVisitors, 0, ',', ' ');
                        ?>
                    </div>
                    <div class="stat-label">Visiteurs Uniques</div>
                </div>
            </div>
        </div>

        <!-- Graphique des visites par jour (derniers 30 jours) -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-chart-line"></i> Évolution des visites (30 derniers jours)
                </h5>
            </div>
            <div class="card-body">
                <canvas id="visitesChart" style="max-height: 300px;"></canvas>
            </div>
        </div>

        <!-- Statistiques par jour -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-calendar-alt"></i> Visites journalières (14 derniers jours)
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Jour</th>
                                <th class="text-center">Nombre de Visites</th>
                                <th class="text-center">Visiteurs Uniques</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Statistiques par jour
                            $stmt = $pdo->query("
                                SELECT 
                                    DATE(visit_time) as date,
                                    COUNT(*) as nb_visites,
                                    COUNT(DISTINCT ip) as nb_uniques
                                FROM visites_catalogue
                                WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 14 DAY)
                                GROUP BY DATE(visit_time)
                                ORDER BY date DESC
                            ");
                            $statsByDay = $stmt->fetchAll();
                            
                            $jours = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
                            
                            foreach ($statsByDay as $stat):
                                $date = new DateTime($stat['date']);
                                $isToday = $date->format('Y-m-d') === date('Y-m-d');
                            ?>
                            <tr <?= $isToday ? 'class="table-success"' : '' ?>>
                                <td>
                                    <strong><?= $date->format('d/m/Y') ?></strong>
                                    <?= $isToday ? '<span class="badge bg-success ms-2">Aujourd\'hui</span>' : '' ?>
                                </td>
                                <td><?= $jours[$date->format('w')] ?></td>
                                <td class="text-center">
                                    <strong><?= number_format($stat['nb_visites'], 0, ',', ' ') ?></strong>
                                </td>
                                <td class="text-center">
                                    <?= number_format($stat['nb_uniques'], 0, ',', ' ') ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Tableau des dernières visites -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-list"></i> Dernières visites
                </h5>
                <div>
                    <select id="limitVisites" class="form-select form-select-sm d-inline-block" style="width: auto;">
                        <option value="50">50 dernières</option>
                        <option value="100">100 dernières</option>
                        <option value="200" selected>200 dernières</option>
                        <option value="500">500 dernières</option>
                    </select>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="visitesTable">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Adresse IP</th>
                                <th>Date et Heure</th>
                                <th>Jour</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Récupérer les dernières visites
                            $limit = 200;
                            $stmt = $pdo->prepare('
                                SELECT id, ip, visit_time
                                FROM visites_catalogue
                                ORDER BY visit_time DESC
                                LIMIT :lim
                            ');
                            $stmt->bindValue(':lim', (int)$limit, PDO::PARAM_INT);
                            $stmt->execute();
                            $visites = $stmt->fetchAll();
                            
                            foreach ($visites as $v):
                                $date = new DateTime($v['visit_time']);
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($v['id']) ?></td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <?= htmlspecialchars($v['ip']) ?>
                                    </span>
                                </td>
                                <td><?= $date->format('d/m/Y H:i:s') ?></td>
                                <td><?= $jours[$date->format('w')] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Script pour le graphique Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Données pour le graphique des 30 derniers jours
<?php
$stmt = $pdo->query("
    SELECT 
        DATE(visit_time) as date,
        COUNT(*) as nb_visites
    FROM visites_catalogue
    WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY DATE(visit_time)
    ORDER BY date ASC
");
$chartData = $stmt->fetchAll();

$labels = [];
$data = [];
foreach ($chartData as $row) {
    $date = new DateTime($row['date']);
    $labels[] = $date->format('d/m');
    $data[] = $row['nb_visites'];
}
?>

const ctxVisites = document.getElementById('visitesChart');
if (ctxVisites) {
    new Chart(ctxVisites, {
        type: 'line',
        data: {
            labels: <?= json_encode($labels) ?>,
            datasets: [{
                label: 'Nombre de visites',
                data: <?= json_encode($data) ?>,
                borderColor: 'rgb(75, 192, 192)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.3,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// Gestion du changement de limite d'affichage
document.getElementById('limitVisites')?.addEventListener('change', function() {
    const limit = this.value;
    // Recharger avec AJAX ou recharger la page
    window.location.reload();
});
</script>

<style>
.stat-card {
    background: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 20px;
    transition: transform 0.2s;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.stat-card.primary { border-left: 4px solid #007bff; }
.stat-card.success { border-left: 4px solid #28a745; }
.stat-card.warning { border-left: 4px solid #ffc107; }
.stat-card.info { border-left: 4px solid #17a2b8; }

.stat-icon {
    font-size: 2rem;
    margin-bottom: 10px;
    opacity: 0.7;
}

.stat-card.primary .stat-icon { color: #007bff; }
.stat-card.success .stat-icon { color: #28a745; }
.stat-card.warning .stat-icon { color: #ffc107; }
.stat-card.info .stat-icon { color: #17a2b8; }

.stat-value {
    font-size: 2.5rem;
    font-weight: bold;
    margin: 10px 0;
    color: #333;
}

.stat-label {
    color: #6c757d;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.card {
    border: none;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.card-header {
    background: #f8f9fa;
    border-bottom: 2px solid #dee2e6;
    font-weight: 600;
}

.table-hover tbody tr:hover {
    background-color: rgba(0,123,255,0.05);
}
</style>

    </div>

    
</div>

    <script>
        // Variables globales
        let currentSection = 'dashboard';

        // Navigation entre sections
        function showSection(sectionName) {
            // Masquer toutes les sections
            document.querySelectorAll('.section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Retirer la classe active de tous les nav-items
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Afficher la section demandée
            document.getElementById(sectionName + '-section').classList.remove('hidden');
            
            // Ajouter la classe active au nav-item cliqué
            event.target.closest('.nav-item').classList.add('active');
            
            currentSection = sectionName;
        }

        // Fonction de recherche
        function searchTable() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            let targetTable;
            
            // Déterminer quelle table rechercher en fonction de la section active
            switch(currentSection) {
                case 'users':
                    targetTable = document.getElementById('usersTable');
                    break;
                case 'cars':
                    targetTable = document.getElementById('carsTable');
                    break;
                case 'bookings':
                    targetTable = document.getElementById('bookingsTable');
                    break;
                default:
                    return;
            }
            
            if (!targetTable) return;
            
            const rows = targetTable.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        }

        // Ajouter l'événement de recherche
        document.getElementById('searchInput').addEventListener('input', searchTable);

        // Fonctions pour les actions sur les demandes d'essai
        function approveBooking(bookingId) {
            if (confirm('Approuver cette demande d\'essai ?')) {
                // Créer un formulaire pour envoyer la requête
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'approve_booking.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'booking_id';
                input.value = bookingId;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function rejectBooking(bookingId) {
            if (confirm('Rejeter cette demande d\'essai ?')) {
                // Créer un formulaire pour envoyer la requête
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'reject_booking.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'booking_id';
                input.value = bookingId;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function deleteBooking(bookingId) {
            if (confirm('Supprimer cette demande d\'essai ?')) {
                // Créer un formulaire pour envoyer la requête
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'delete_booking.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'booking_id';
                input.value = bookingId;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }



        // Fonction de génération de rapport
        function generateReport() {
            const reportUrl = 'generate_report.php';
            window.open(reportUrl, '_blank');
            showNotification('Génération du rapport en cours...', 'info');
        }

        // Système de notifications
        function showNotification(message, type = 'info') {
            // Supprimer les notifications existantes
            const existingNotifications = document.querySelectorAll('.notification');
            existingNotifications.forEach(notif => notif.remove());

            const notification = document.createElement('div');
            notification.className = 'notification';
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : type === 'warning' ? '#f39c12' : '#3498db'};
                color: white;
                padding: 15px 25px;
                border-radius: 8px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                z-index: 10000;
                animation: slideInRight 0.3s ease;
                max-width: 350px;
                word-wrap: break-word;
            `;
            
            // Ajouter une icône basée sur le type
            const icon = type === 'success' ? 'fa-check-circle' : 
                        type === 'error' ? 'fa-times-circle' : 
                        type === 'warning' ? 'fa-exclamation-triangle' : 
                        'fa-info-circle';
            
            notification.innerHTML = `
                <i class="fas ${icon}" style="margin-right: 10px;"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            // Auto-remove après 4 secondes
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }, 4000);
        }

        // Animations CSS pour les notifications
        const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { 
            transform: translateX(100%); 
            opacity: 0; 
        }
        to { 
            transform: translateX(0); 
            opacity: 1; 
        }
    }
    @keyframes slideOutRight {
        from { 
            transform: translateX(0); 
            opacity: 1; 
        }
        to { 
            transform: translateX(100%); 
            opacity: 0; 
        }
    }
    
    /* Améliorer le responsive */
    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
        .quick-actions {
            flex-direction: column;
        }
        .section-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 15px;
        }
        .data-table {
            font-size: 0.9rem;
        }
        .data-table th,
        .data-table td {
            padding: 10px 8px;
        }
    }
    
    /* Style pour les boutons de statut actifs */
    .status-badge:active {
        transform: scale(0.95);
    }
    
    /* Améliorer l'accessibilité */
    .nav-item:focus,
    .btn:focus,
    .status-badge:focus {
        outline: 2px solid #3498db;
        outline-offset: 2px;
    }
`;
document.head.appendChild(style);

        // Auto-actualisation des données (optionnel)
        function autoRefresh() {
            // Actualiser uniquement les statistiques
            fetch('get_stats.php')
                .then(response => response.json())
                .then(data => {
                    // Mettre à jour les valeurs des cartes statistiques
                    if (data.success) {
                        document.querySelector('.stat-card.primary .stat-value').textContent = data.totalUsers;
                        document.querySelector('.stat-card.success .stat-value').textContent = data.activeUsers;
                        document.querySelector('.stat-card.warning .stat-value').textContent = data.totalDemandes;
                        document.querySelector('.stat-card.info .stat-value').textContent = data.totalVoitures;
                        document.querySelector('.notification-count').textContent = data.totalDemandes;
                    }
                })
                .catch(error => console.log('Erreur lors de la mise à jour:', error));
        }

        // Actualiser les stats toutes les 5 minutes
        setInterval(autoRefresh, 300000);

        // Gestion des erreurs PHP (si des messages sont passés via session)
        <?php if (isset($_SESSION['success_message'])): ?>
            showNotification('<?= $_SESSION['success_message'] ?>', 'success');
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            showNotification('<?= $_SESSION['error_message'] ?>', 'error');
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        // Initialisation
        document.addEventListener('DOMContentLoaded', function() {
            // Animation d'entrée pour les cartes
            const cards = document.querySelectorAll('.stat-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                    card.style.transition = 'all 0.6s ease';
                }, index * 100);
            });

            // Afficher une notification de bienvenue
            setTimeout(() => {
                showNotification('Bienvenue dans votre dashboard SuperCar !', 'success');
            }, 1000);
        });

        // Raccourcis clavier
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + K pour focus sur la recherche
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                document.getElementById('searchInput').focus();
            }
            
            // Échap pour effacer la recherche
            if (e.key === 'Escape') {
                document.getElementById('searchInput').value = '';
                searchTable();
            }
        });

        // Gestion du dropdown de notifications
        function toggleNotifDropdown() {
            var el = document.getElementById('notifDropdown');
            el.style.display = (el.style.display === 'none' || el.style.display === '') ? 'block' : 'none';
            // Marquer toutes les notifications comme lues
            if (el.style.display === 'block') {
                fetch('marque_notifications_lues.php').then(() => {
                    // Optionnel : rafraîchir le badge ou la page
                    document.querySelector('.notification-count')?.remove();
                });
            }
        }

        // Fermer le dropdown si clic en dehors
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('notifDropdown');
            const bellIcon = document.querySelector('.notification-bell');
            
            if (!bellIcon.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        });
    </script>
</body>
</html>

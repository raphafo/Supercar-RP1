<?php
session_start(); // Toujours en haut

require_once '../db_connexion.php';

$message = '';
$messageType = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $ville = trim($_POST['ville'] ?? '');
    $password = $_POST['password'] ?? '';
    $actif = isset($_POST['actif']) ? 1 : 0;
    $role = $_POST['role'] ?? 'user';
    
    // Validation des champs
    if (empty($nom) || empty($prenom) || empty($email) || empty($password)) {
        $message = 'Tous les champs obligatoires doivent être remplis.';
        $messageType = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'L\'adresse email n\'est pas valide.';
        $messageType = 'error';
    } elseif (strlen($password) < 6) {
        $message = 'Le mot de passe doit contenir au moins 6 caractères.';
        $messageType = 'error';
    } else {
        try {
            // Vérifier si l'email existe déjà
            $check_stmt = $pdo->prepare("SELECT id FROM inscription WHERE email = ?");
            $check_stmt->execute([$email]);
            
            if ($check_stmt->rowCount() > 0) {
                $message = 'Cet email est déjà utilisé par un autre utilisateur.';
                $messageType = 'error';
            } else {
                // Hasher le mot de passe
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $date_inscription = date('Y-m-d H:i:s');
                
                // Insérer le nouvel utilisateur
                $stmt = $pdo->prepare("INSERT INTO inscription (nom, prenom, email, ville, password, actif, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$nom, $prenom, $email, $ville, $hashed_password, $actif, $role]);
                
                $_SESSION['success_message'] = 'Utilisateur ajouté avec succès !';
                header('Location: dashadmin.php'); // Rediriger vers votre page admin
                exit;
            }
        } catch (PDOException $e) {
            $message = 'Erreur lors de l\'ajout de l\'utilisateur : ' . $e->getMessage();
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Utilisateur - SuperCar Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .card-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .card-header p {
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .card-body {
            padding: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 0.95rem;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            margin: 0;
            transform: scale(1.2);
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-right: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .container {
                margin: 20px auto;
                padding: 0 15px;
            }
            
            .card-body {
                padding: 25px;
            }
        }

        .required {
            color: #dc3545;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #764ba2;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashadmin.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
            Retour au tableau de bord
        </a>

        <div class="card">
            <div class="card-header">
                <h1><i class="fas fa-user-plus"></i> Ajouter un Utilisateur</h1>
                <p>Créer un nouveau compte utilisateur pour SuperCar</p>
            </div>

            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType == 'error' ? 'error' : 'success' ?>">
                        <i class="fas fa-<?= $messageType == 'error' ? 'exclamation-triangle' : 'check-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="nom">
                                Nom <span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="nom" 
                                   name="nom" 
                                   value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" 
                                   required
                                   placeholder="Nom de famille">
                        </div>

                        <div class="form-group">
                            <label for="prenom">
                                Prénom <span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="prenom" 
                                   name="prenom" 
                                   value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" 
                                   required
                                   placeholder="Prénom">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">
                            Email <span class="required">*</span>
                        </label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                               required
                               placeholder="exemple@email.com">
                    </div>

                    <div class="form-group">
                        <label for="ville">
                            Ville
                        </label>
                        <input type="text" 
                               id="ville" 
                               name="ville" 
                               value="<?= htmlspecialchars($_POST['ville'] ?? '') ?>"
                               placeholder="Ville de résidence">
                    </div>

                    <div class="form-group">
                        <label for="password">
                            Mot de passe <span class="required">*</span>
                        </label>
                        <input type="password" 
                               id="password" 
                               name="password" 
                               required
                               minlength="6"
                               placeholder="Minimum 6 caractères">
                    </div>

                    <div class="form-group">
                        <label for="role">
                            Rôle
                        </label>
                        <select id="role" name="role" class="form-control">
                            <option value="user" <?= (!isset($_POST['role']) || $_POST['role'] == 'user') ? 'selected' : '' ?>>Utilisateur</option>
                            <option value="admin" <?= (isset($_POST['role']) && $_POST['role'] == 'admin') ? 'selected' : '' ?>>Administrateur</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" 
                                   id="actif" 
                                   name="actif" 
                                   <?= isset($_POST['actif']) ? 'checked' : '' ?>>
                            <label for="actif">Compte actif</label>
                        </div>
                    </div>

                    <div style="margin-top: 30px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            Créer l'utilisateur
                        </button>
                        
                        <a href="dashadmin.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i>
                            Annuler
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Validation côté client
        document.querySelector('form').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const email = document.getElementById('email').value;
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Le mot de passe doit contenir au moins 6 caractères.');
                return;
            }
            
            if (!email.includes('@')) {
                e.preventDefault();
                alert('Veuillez saisir une adresse email valide.');
                return;
            }
        });
    </script>
</body>
</html>
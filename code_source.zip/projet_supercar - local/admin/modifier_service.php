<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") exit("unauthorized");


require_once '../db_connexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $titre = $_POST['titre'] ?? '';
    $icone = $_POST['icone'] ?? '';
    $description = $_POST['description'] ?? '';
    $lien = $_POST['lien'] ?? '';
    $type = $_POST['type'] ?? '';
    $details = $_POST['details'] ?? '';

    try {
        $stmt = $pdo->prepare("UPDATE services SET titre=?, icone=?, description=?, lien=?, type=?, details=? WHERE id=?");
        
        if ($stmt->execute([$titre, $icone, $description, $lien, $type, $details, $id])) {
            echo "success";
        } else {
            echo "error";
        }
    } catch (PDOException $e) {
        echo "error";
    }
    exit;
}
echo "invalid";
?>

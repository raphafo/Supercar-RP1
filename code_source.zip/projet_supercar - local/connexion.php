<?php
session_start();

require_once 'db_connexion.php';

$error = "";
$prefilledEmail = "";

// Si formulaire soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"] ?? "";
    $password = $_POST["password"] ?? "";
    $prefilledEmail = htmlspecialchars($email);

    // Vérification email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Veuillez entrer un email valide.";
    } else {
        // Requête pour récupérer l'utilisateur (avec le rôle)
        $sql = "SELECT id, nom, email, password, role FROM inscription WHERE email = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            if (password_verify($password, $user["password"])) {
                // Authentification réussie
                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_nom"] = $user["nom"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["role"] = $user["role"];

                // Redirection selon le rôle
                if ($user["role"] === "admin") {
                    header("Location: admin/dashadmin.php");
                } else {
                    header("Location:dashboard.php");
                }
                exit();
            } else {
                $error = "Mot de passe incorrect.";
            }
        } else {
            $error = "Email non trouvé.";
        }
    }
}
if (isset($pdo) && $pdo) {
    $pdo = null;
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/all.min.css">
    
</head>

<body class="bg-light">
        <div class="container">
            <div class="row mt-5">
                <div class="col-lg-4 bg-white mx-auto rounded-top">
                  <h2 class="text-center">Connexion</h2>
                  
                  <p class="text-center text-muted lead">Se connecter à SuperCar</p>
                  
                  <form action="connexion.php" method="POST">
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fa fa-envelope"></i> </span>
                        <input type="text" name="email" id="email" value="<?= $prefilledEmail ?>" required class="form-control" placeholder="Votre E-mail">
                    </div>
                
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fa fa-lock"></i> </span>
                        <input type="password" name="password" class="form-control" placeholder="Votre Mot de passe" required>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-success w-100 py-2">Se connecter</button>
                        <?php if (!empty($error)) : ?>
                        <p class="text-danger text-center"><?= $error ?></p>
                        <?php endif; ?>
                        <p class="text-center">
                            N'avez-vous pas de compte ? <a href="inscription.php">S'inscrire</a>
                        </p>
                        <p class="text-center">
                            Retour à la page d'accueil <a href="index.html">Accueil</a>
                        </p>
                    </div>
                </form>
                </div>
            </div>
        </div>
        <center>
        <footer>
        <p>&copy; SUPERCAR 24-26. By Student MCCI. SIO </p>
        </footer>
      </center>
</body>
</html>
<script src="bootstrap.bundle.js"></script>

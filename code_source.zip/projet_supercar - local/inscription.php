<?php
// Récupérer l'email depuis l'URL s'il existe
$prefilledEmail = isset($_GET['email']) ? htmlspecialchars($_GET['email']) : '';
$prefilledNom = isset($_GET['nom']) ? htmlspecialchars($_GET['nom']) : '';
$prefilledPrenom = isset($_GET['prenom']) ? htmlspecialchars($_GET['prenom']) : '';
?>


<!DOCTYPE HTML>
<html lang=fr>

<head>
    <title>Inscription</title>
<meta charset = "UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body class="bg-light">
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid px-0">
        <!-- Logo à gauche -->
        <a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">
            Super<span>car</span>
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
            <span class="oi oi-menu"></span> Menu
        </button>
        <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav mx-auto" style="max-width: 800px; width: 100%; display: flex; justify-content: center; flex-wrap: nowrap;">
                  <li class="nav-item"><a href="index.html" class="nav-link">Accueil</a></li>
                  <li class="nav-item"><a href="catalogue.php" class="nav-link">Voitures</a></li>
                  <li class="nav-item"><a href="demande.php" class="nav-link">Demande d’essai</a></li>
                  <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                  <li class="nav-item"><a href="contact.html" class="nav-link">Contactez-nous</a></li>
                </ul>
              
                <!-- Inscription à droite -->
                <ul class="navbar-nav" style="margin-right: 50px;">
                  <li class="nav-item"><a href="connexion.php" class="nav-link">Connexion</a></li>
                </ul>
              </div>
</nav>

<style>
    /* Ajustements pour le groupe de liens */
    @media (min-width: 992px) {
        .navbar-nav .nav-item[style*="inline-flex"] {
            display: inline-flex !important;
            align-items: center;
        }
        
        .navbar-brand {
            position: relative;
            left: -30px;
        }
        
        #ftco-nav {
            width: calc(100% - 100px);
        }
    }
    
    /* Version mobile */
    @media (max-width: 991px) {
        .navbar-nav .nav-item[style*="inline-flex"] {
            display: block !important;
        }
        
        .navbar-nav .nav-item[style*="inline-flex"] span {
            display: none;
        }
    }
</style>
  <div class="containe">
      <div class="row mt-5">
          <div class="col-lg-4 bg-white mx-auto rounded-top">
            <h2 class="text-center">Inscription</h2>
            <p class="text-center text-muted lead">Simple et Rapide</p>

            <form method="POST" action="inscrire.php">
              <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fa fa-user"></i> </span>
                  <input type="text" name="nom" id="nom" value="<?= $prefilledNom ?>" required class="form-control" placeholder="Votre Nom" pattern="[A-Za-zÀ-ÿ\s\-']+">
              </div>

              <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fa fa-user"></i> </span>
                  <input type="text" name="prenom" id="prenom" value="<?= $prefilledPrenom ?>" required class="form-control" placeholder="Votre prénom" pattern="[A-Za-zÀ-ÿ\s\-']+">
              </div>

              <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fa fa-envelope"></i> </span>
                  <input type="email" name="email" id="email" value="<?= $prefilledEmail ?>" required class="form-control" placeholder="Votre E-mail">
              </div>

              <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fa fa-map-marker-alt"></i> </span>
                  <input type="text" name="ville"  class="form-control" placeholder="Votre ville">
              </div>

              <div class="input-group mb-3">
                <span class="input-group-text"><i class="fa fa-lock"></i> </span>
                <input type="password" name="password" class="form-control" placeholder="Votre Mot de passe"
                       pattern="^(?=.*[A-Z])(?=.*[\W_]).{5,}$" required
                       title="Au moins 5 caractères, une majuscule et un caractère spécial">
            </div>
            <div class="d-grid">
              <button type="submit" name="valider" class="btn btn-success w-100 py-2">S'inscrire</button>
              <p class="text-center text-muted">
                     En cliquant sur S'inscrire vous acceptez nos <a href="">conditions générales</a>, notre <a href="">politique 
                     de confidentialité</a> et notre <a href="">Politique d'utilisation</a> des cookies. 
                  </p>
                  <p class="text-center">
                      Avez vous déja un compte? <a href="connexion.php">Connexion</a>
                  </p>
              </div>

            </form>
          </div>
      </div>
  </div>
      <center>
        <footer>
        <p>&copy; SUPERCAR 24-26. By Student MCCI. SIO </p>
        </footer>
      </center>
</body>
</html>

<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="js/google-map.js"></script>
<script src="js/main.js"></script>
<script src="bootstrap.bundle.js"></script>
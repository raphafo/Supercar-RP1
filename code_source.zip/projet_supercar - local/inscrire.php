<?php
session_start();

require_once 'db_connexion.php'; // $pdo est créé ici

// Vérification du formulaire
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Nom = $_POST["nom"] ?? null;
    $Prenom = $_POST["prenom"] ?? null;
    $Email = $_POST["email"] ?? null;
    $Ville = $_POST["ville"] ?? null;
    $password = $_POST["password"] ?? null;

    if (!$Nom || !$Prenom || !$Email || !$Ville || !$password) {
        die("Erreur : Veuillez remplir tous les champs.");
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Préparation et exécution de l'insertion avec PDO
    $stmt = $pdo->prepare("INSERT INTO inscription (nom, prenom, email, ville, password) VALUES (?, ?, ?, ?, ?)");
    if ($stmt->execute([$Nom, $Prenom, $Email, $Ville, $hashed_password])) {
        echo "Merci de vous être inscrit.<br>";

        // ✅ Si une demande d'essai est en attente dans la session
        if (!empty($_SESSION['pending_essai'])) {
            try {
                $essai = $_SESSION['pending_essai'];
                $insertEssai = $pdo->prepare("INSERT INTO essai 
                    (nom, prenom, email, lieurecup, lieudepot, daterecup, datedepot, heurerecup)
                    VALUES (:nom, :prenom, :email, :lieurecup, :lieudepot, :daterecup, :datedepot, :heurerecup)");

                $insertEssai->execute([
                    ':nom' => $essai['nom'],
                    ':prenom' => $essai['prenom'],
                    ':email' => $essai['email'],
                    ':lieurecup' => $essai['lieurecup'],
                    ':lieudepot' => $essai['lieudepot'] ?? null,
                    ':datedepot' => $essai['datedepot']?? null,
                    ':daterecup' => $essai['daterecup'] ?? null,
                    ':heurerecup' => $essai['heurerecup'] ?? '00:00:00'
                ]);

                unset($_SESSION['pending_essai']); // Nettoyage
                echo "Demande d'essai enregistrée avec succès. <br>";
                
            } catch (Exception $e) {
                echo "Erreur lors de l'enregistrement de la demande d'essai : " . $e->getMessage();
            }
        }

        echo "<a href='connexion.php'>Connectez-vous ici</a>";
        echo"                               ";
        echo "<a href='index.html'>Retour à la page d'accueil</a>";
    } else {
        echo "Erreur lors de l'inscription.";
    }
}
?>

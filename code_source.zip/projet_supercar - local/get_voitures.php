<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

try {
    require_once 'db_connexion.php';

    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = 6;
    $offset = ($page - 1) * $limit;

    // Construction de la requête avec filtres
    $where = "WHERE 1=1";
    $params = [];
    $paramCount = 0;

    // Filtre par marque/nom
  if (!empty($_GET['marque'])) {
    $where .= " AND marque LIKE ?";
    $params[] = ['value' => '%' . $_GET['marque'] . '%', 'type' => PDO::PARAM_STR];
    $paramCount += 1;
}

    // Filtre par disponibilité
    if (isset($_GET['disponible']) && $_GET['disponible'] !== '') {
        $where .= " AND disponible = ?";
        $params[] = ['value' => (int)$_GET['disponible'], 'type' => PDO::PARAM_INT];
        $paramCount += 1;
    }

    // Requête pour compter le total
    $countQuery = "SELECT COUNT(*) as total FROM voitures $where";
    $countStmt = $pdo->prepare($countQuery);
    
    // Lier les paramètres pour le count
    foreach ($params as $index => $param) {
        $countStmt->bindValue($index + 1, $param['value'], $param['type']);
    }
    
    $countStmt->execute();
    $totalCars = $countStmt->fetch()['total'];

    // Requête pour récupérer les voitures
    $query = "SELECT * FROM voitures $where ORDER BY id DESC LIMIT ? OFFSET ?";
    $stmt = $pdo->prepare($query);
    
    // Lier les paramètres de filtres
    foreach ($params as $index => $param) {
        $stmt->bindValue($index + 1, $param['value'], $param['type']);
    }
    
    // Lier les paramètres de pagination
    $stmt->bindValue($paramCount + 1, $limit, PDO::PARAM_INT);
    $stmt->bindValue($paramCount + 2, $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $cars = $stmt->fetchAll();

    echo json_encode([
        'success' => true,
        'cars' => $cars,
        'totalPages' => ceil($totalCars / $limit),
        'currentPage' => $page,
        'totalCars' => (int)$totalCars
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'cars' => [],
        'totalPages' => 0,
        'currentPage' => isset($page) ? $page : 1,
        'totalCars' => 0
    ]);
}
?>
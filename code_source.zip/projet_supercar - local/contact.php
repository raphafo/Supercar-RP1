<?php
session_start();

require_once 'db_connexion.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = htmlspecialchars(trim($_POST["nom"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $sujet = htmlspecialchars(trim($_POST["sujet"]));
    $message = htmlspecialchars(trim($_POST["message"]));

    // Vérifie que nom et email sont présents
    if (empty($nom) || empty($email)) {
        die("Erreur : nom et email sont obligatoires !");
    }

    try {
        // Vérifier si la colonne date_envoi existe
        $check_column = $pdo->query("SHOW COLUMNS FROM contactez LIKE 'date_envoi'");
        if ($check_column->rowCount() == 0) {
            // Ajouter la colonne si elle n'existe pas
            $pdo->exec("ALTER TABLE contactez ADD date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP");
        }

        // Préparation de la requête SQL sécurisée avec PDO
        $stmt = $pdo->prepare("INSERT INTO contactez (nom, email, sujet, message, date_envoi) VALUES (?, ?, ?, ?, NOW())");
        
        // Exécution avec les paramètres
        if ($stmt->execute([$nom, $email, $sujet, $message])) {
            $_SESSION['message_envoye'] = true;
            echo "Message envoyé avec succès !";
        } else {
            echo "Erreur lors de l'envoi";
        }

    } catch (PDOException $e) {
        echo "Erreur de base de données : " . $e->getMessage();
    } catch (Exception $e) {
        echo "Erreur : " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>SuperCar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <link rel="stylesheet" href="../css/aos.css">

    <link rel="stylesheet" href="../css/ionicons.min.css">

    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container-fluid px-0">
        <!-- Logo à gauche -->
        <a class="navbar-brand ml-lg-5 ml-3" href="../index.html" style="margin-right: -50px;">
          Super<span>car</span>
        </a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
          <span class="oi oi-menu"></span> Menu
        </button>
    
        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav mx-auto" style="max-width: 800px; width: 100%; display: flex; justify-content: center; flex-wrap: nowrap;">
            <li class="nav-item"><a href="../index.html" class="nav-link">Accueil</a></li>
            <li class="nav-item"><a href="../catalogue.php" class="nav-link">Voitures</a></li>
            <li class="nav-item"><a href="../demande.php" class="nav-link">Demande d’essai</a></li>
            <li class="nav-item"><a href="../services.php" class="nav-link">Services</a></li>
            <li class="nav-item"><a href="../contact.html" class="nav-link">Contactez-nous</a></li>
          </ul>
        
          <!-- Inscription à droite -->
          <ul class="navbar-nav" style="margin-right: 50px;">
            <li class="nav-item"><a href="../inscription.php" class="nav-link">Inscription</a></li>
          </ul>
        </div>
    </nav>
    
    <style>
      /* Ajustements pour le groupe de liens */
      @media (min-width: 992px) {
        .navbar-nav .nav-item[style*="inline-flex"] {
          display: inline-flex !important;
          align-items: center;
        }
        
        .navbar-brand {
          position: relative;
          left: -30px;
        }
        
        #ftco-nav {
          width: calc(100% - 100px);
        }
      }
      
      /* Version mobile */
      @media (max-width: 991px) {
        .navbar-nav .nav-item[style*="inline-flex"] {
          display: block !important;
        }
        
        .navbar-nav .nav-item[style*="inline-flex"] span {
          display: none;
        }
      }
    </style>
    
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('../images/pieces.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="../index.html">Accueil<i class="ion-ios-arrow-forward"></i></a></span> <span>Accessoires <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Nos choix</h1>
          </div>
        </div>
      </div>
	<section id="services" class="services section">
        
		<!-- Section Title -->
		<div data-aos="fade-up">
		</div><!-- End Section Title -->
	
		  <div class="container">
	
			  <div data-aos="fade-up" data-aos-delay="100">
				<div class="service-item">
				</head>
				<body>
				
	  <?php
// Connexion à la base
$conn = new mysqli('localhost', 'root', '', 'supercar');
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

$sql = "SELECT * FROM pieces";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<div class="labo">';
    while ($row = $result->fetch_assoc()) {
        echo '<div class="card">';
        echo "<div><img src='../images/{$row['image']}' alt='{$row['titre']}'></div>";
        echo "<div><button class='btn'>{$row['titre']}</button></div>";
        echo '</div>';
    }
    echo '</div>';
} else {
    echo "<p>Aucun service de pièces disponible.</p>";
}
$conn->close();
?>




          
          <style>
						body {
							font-family: Questrial, Arial, Helvetica Neue, Helvetica, sans-serif;
							background-color: #f8f9fa;
							margin: 0;
							padding: 0;
						}
            .card{display: flex;
              flex-direction: column;
              align-items: center;
              text-align: center;
              padding: 20px;
              border: 1px solid #ddd;
              background-color: #f9f9f9;
              align-items: center;
              justify-content: space-between;
}
            
						.labo { max-width:1161px;
                     margin: 20px auto;
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 45px;
   
              }
						
						.card img {
							max-width:90%;
              max-height:160px;
						}
						.btn {
							display: block;
							background-color: #041d8e;
							color: white;
							text-decoration: none;
							padding: 20px;
							font-weight: bold;
							margin-top: 5px;
							border-radius: 5px;
						}
						.btn:hover {
							background-color:#007bff;
						}
					</style>
          <footer style="
          background: linear-gradient(135deg, #247eec, #12906c, #2d73ed);
          color: white;
          padding: 1.5rem 0;
          text-align: center;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          position: relative;
          margin-top: 3rem;
          box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
          ">
          <div style="
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
          ">
            <p style="
              margin: 0;
              font-size: 1.1rem;
              letter-spacing: 1px;
              display: flex;
              justify-content: center;
              align-items: center;
              gap: 10px;
              flex-wrap: wrap;
            ">
              <span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
              <span style="color: rgba(255,255,255,0.8);">|</span>
              <span>By Student MCCI</span>
              <span style="color: rgba(255,255,255,0.8);">|</span>
              <span>SIO</span>
            </p>
            
            <div style="
              margin-top: 1rem;
              display: flex;
              justify-content: center;
              gap: 1.5rem;
            ">
              <a href="#contact.html" style="color: white; text-decoration: none; transition: all 0.3s;">
                <i class="fas fa-envelope"></i> Contact
              </a>
              <a href="#" style="color: white; text-decoration: none; transition: all 0.3s;">
                <i class="fas fa-shield-alt"></i> Confidentialité
              </a>
              <a href="#" style="color: white; text-decoration: none; transition: all 0.3s;">
                <i class="fas fa-file-alt"></i> Mentions légales
              </a>
            </div>
          </div>
          </footer>
          
				</body>
				</html>
				

  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <script src="../js/jquery.timepicker.min.js"></script>
  <script src="../js/scrollax.min.js"></script>
  <script src="../js/main.js"></script>
    
  </body>
</html>
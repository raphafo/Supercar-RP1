
<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: connexion.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --light: #f8f9fa;
            --dark: #1a1a2e;
            --border-radius: 12px;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            /* Image de fond */
            background: url('images/supe.jpeg') center/100% no-repeat fixed;
            /* Au lieu de 'cover' qui étire à 100%, utilisez un pourcentage */
        }

        /* Overlay semi-transparent pour améliorer la lisibilité */
        body::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4); /* Ajustez l'opacité (0.4 = 40%) */
            z-index: 0;
        }

        .dashboard-card {
            background: rgba(255, 255, 255, 0.9); /* Fond semi-transparent */
            border-radius: var(--border-radius);
            padding: 30px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .welcome-message h1 {
            color: var(--primary);
            margin-bottom: 10px;
        }

        .action-btn {
            display: block;
            background: var(--primary);
            color: white;
            padding: 12px;
            border-radius: var(--border-radius);
            text-decoration: none;
            margin: 15px 0;
            transition: all 0.3s;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background: #3a56d4; /* Couleur légèrement plus foncée au survol */
        }

        .logout-btn {
            background: none;
            border: none;
            color: #666;
            margin-top: 20px;
            cursor: pointer;
            transition: color 0.3s;
        }

        .logout-btn:hover {
            color: #333;
        }
    </style>
</head>
<body>

    <div class="dashboard-card">
        <div class="welcome-message">
            <h1><i class="fas fa-user-circle"></i> Bienvenue, <?php echo htmlspecialchars($_SESSION["user_nom"]); ?></h1>
            <p>Que souhaitez-vous faire aujourd'hui ?</p>
        </div>

        <a href="demande.php" class="action-btn">
            <i class="fas fa-file-alt"></i> Nouvelle demande
        </a>
        <a href="catalogue.php" class="action-btn">
            <i class=" fas fa-car"></i> Catalogue de voiture 
        </a>


        </a>

        <a href="index.html" class="action-btn">
            <i class="fas fa-home"></i> Accueil
        </a>

        <a href="contact.html" class="action-btn">
            <i class="fas fa-envelope"></i> Contactez-nous
        </a>

        <button class="logout-btn" onclick="window.location.href='logout.php'">
            <i class="fas fa-sign-out-alt"></i> Déconnexion
        </button>
    </div>

</body>
</html>
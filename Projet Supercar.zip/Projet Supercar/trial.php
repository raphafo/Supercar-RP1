<?php
header('Content-Type: application/json; charset=utf-8');
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// 1. Vérification stricte de la connexion
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    exit(json_encode([
        'success' => false,
        'code' => 'NOT_LOGGED_IN',
        'message' => 'Authentification requise'
    ]));
}

require 'db_connexion.php';

try {
    // 2. Validation des champs (version simplifiée)
    $requiredFields = ['nom', 'prenom', 'email', 'lieurecup', 'daterecup', 'id_voiture'];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("Champ manquant: $field", 400);
        }
    }

    // 3. Validation des formats
    $id_voiture = (int)$_POST['id_voiture'];
    if ($id_voiture <= 0) throw new Exception("ID voiture invalide", 400);
    
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Email invalide", 400);
    }

    // 4. Vérification existence voiture (optionnel mais recommandé)
    $stmt = $pdo->prepare("SELECT id FROM voitures WHERE id = ?");
    $stmt->execute([$id_voiture]);
    if (!$stmt->fetch()) {
        throw new Exception("Voiture introuvable", 404);
    }

    // 5. Vérification demande existante 
    $stmt = $pdo->prepare("SELECT id FROM essai WHERE user_id = ? AND daterecup >= NOW() - INTERVAL 7 DAY");
    $stmt->execute([$_SESSION['user_id']]);
    if ($stmt->fetch()) {
        throw new Exception("Demande déjà existante", 409); // HTTP 409 Conflict
    }

    // 6. Insertion de la demande (version sécurisée)
    $stmt = $pdo->prepare("INSERT INTO essai 
        (nom, prenom, email, lieurecup, lieudepot, daterecup, datedepot, heurerecup, id_voiture, user_id)
        VALUES (:nom, :prenom, :email, :lieurecup, :lieudepot, :daterecup, :datedepot, :heurerecup, :id_voiture, :user_id)");

    $success = $stmt->execute([
        ':nom'        => $_POST['nom'],
        ':prenom'     => $_POST['prenom'],
        ':email'      => $_POST['email'],
        ':lieurecup'  => $_POST['lieurecup'],
        ':lieudepot'  => $_POST['lieudepot'] ?? null,
        ':daterecup'  => $_POST['daterecup'],
        ':datedepot'  => $_POST['datedepot'] ?? null,
        ':heurerecup' => $_POST['heurerecup'] ?? '00:00',
        ':id_voiture' => $id_voiture,
        ':user_id'    => $_SESSION['user_id'] // Clé étrangère importante
    ]);

    if (!$success) {
        throw new Exception("Erreur base de données", 500);
    }

    // 7. Réponse succès
    echo json_encode([
        'success' => true,
        'message' => 'Réservation confirmée',
        'reservation_id' => $pdo->lastInsertId()
    ]);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 400);
    echo json_encode([
        'success' => false,
        'code' => method_exists($e, 'getCode') ? $e->getCode() : 'ERROR',
        'message' => $e->getMessage()
    ]);
}
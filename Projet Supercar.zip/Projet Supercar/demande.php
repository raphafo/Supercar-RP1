<?php
// 1. Vérification de connexion
require_once 'verif_connexion.php';

// 2. Connexion à la base de données
$host = 'localhost';
$dbname = 'supercar';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// 3. Récupération de l'ID voiture
$id_voiture = isset($_GET['id_voiture']) ? (int)$_GET['id_voiture'] : 0;
if ($id_voiture <= 0) {
    header("Location: catalogue.php?error=no_car_selected");
    exit();
}

// 4. Vérification que la voiture existe
try {
    $stmt = $pdo->prepare("SELECT marque FROM voitures WHERE id = ?");
    $stmt->execute([$id_voiture]);
    $voiture = $stmt->fetch();
    
    if (!$voiture) {
        header("Location: catalogue.php?error=invalid_car");
        exit();
    }
} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$email = isset($_SESSION['email']) ? $_SESSION['email'] : '';
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Demande</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
		<div class="container-fluid px-0">
			<!-- Logo à gauche -->
			<a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">
				Super<span>car</span>
			</a>
			
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
				<span class="oi oi-menu"></span> Menu
			</button>
	
			<div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav mx-auto" style="max-width: 800px; width: 100%; display: flex; justify-content: center; flex-wrap: nowrap;">
                  <li class="nav-item"><a href="index.html" class="nav-link">Accueil</a></li>
                  <li class="nav-item"><a href="catalogue.php" class="nav-link">Voitures</a></li>
                  <li class="nav-item"><a href="demande.php" class="nav-link">Demande d’essai</a></li>
                  <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                  <li class="nav-item"><a href="contact.html" class="nav-link">Contactez-nous</a></li>
                </ul>
              
                <!-- Inscription à droite -->
                <?php
if (session_status() === PHP_SESSION_NONE) session_start();

$isConnected = isset($_SESSION['user_id']);
$nom = $isConnected && isset($_SESSION['user_nom']) ? $_SESSION['user_nom'] : 'Utilisateur';
$email = $isConnected && isset($_SESSION['email']) ? $_SESSION['email'] : '';
$initial = $isConnected ? strtoupper($nom[0]) : '';

?>
<style>
  .user-icon {
  position: relative;
  width: 45px;
  height: 45px;
  background-color:rgb(105, 119, 134);
  border-radius: 50%;
  color: white;
  font-size: 20px;
  text-align: center;
  line-height: 45px;
}


  .online-indicator {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 10px;
    height: 10px;
    background-color: #28a745;
    border: 2px solid white;
    border-radius: 50%;
  }

  @media (max-width: 991px) {
    .user-icon {
      margin-right: 0;
    }
  }
</style>

<a class="nav-link dropdown-toggle p-0 mr-3" href="#" id="userDropdown" role="button"
   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="position: relative;">
  <div class="user-icon d-flex align-items-center justify-content-center">
    <i class="fas fa-user"></i>
    <?php if ($isConnected): ?>
      <span class="online-indicator"></span>
    <?php endif; ?>
  </div>
</a>
    <div class="dropdown-menu dropdown-menu-right custom-dropdown profile-dropdown" aria-labelledby="userDropdown" style="min-width: 220px;">
      <?php if ($isConnected): ?>
        <span class="dropdown-item-text fw-bold"><?= $nom ?></span>
        <span class="dropdown-item-text text-muted small"><?= $email ?></span>
        <div class="dropdown-divider my-2"></div>
        <a class="dropdown-item text-danger small" href="logout.php">Se déconnecter</a>
      <?php else: ?>
        <a class="dropdown-item" href="connexion.php">Connexion</a>
        <a class="dropdown-item" href="inscription.php">Inscription</a>
      <?php endif; ?>
    </div>
  </li>
</ul>


 </div>
	</nav>
	
	<style>
		/* Ajustements pour le groupe de liens */
		@media (min-width: 992px) {
			.navbar-nav .nav-item[style*="inline-flex"] {
				display: inline-flex !important;
				align-items: center;
			}
			
			.navbar-brand {
				position: relative;
				left: -30px;
			}
			
			#ftco-nav {
				width: calc(100% - 100px);
			}
		}
		
		/* Version mobile */
		@media (max-width: 991px) {
			.navbar-nav .nav-item[style*="inline-flex"] {
				display: block !important;
			}
			
			.navbar-nav .nav-item[style*="inline-flex"] span {
				display: none;
			}
.dropdown-menu {
  right: auto !important;
  left: 0 !important;
  transform: none !important;
}

@media (max-width: 991px) {
  .dropdown-menu {
    right: 0 !important;
    left: auto !important;
  }
}
.profile-dropdown {
  padding: 10px 15px;
  border-radius: 12px;
  font-size: 14px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.profile-dropdown .dropdown-item-text {
  font-size: 13px;
  padding: 2px 0;
}

.profile-dropdown .dropdown-item {
  font-size: 13px;
  padding: 6px 0;
}

		}
	</style>
<style>
  .custom-dropdown {
    left: auto !important;
    right: 0 !important;
    transform: none !important;
  }

  @media (max-width: 500px) {
  .custom-dropdown {
    max-width: calc(100vw - 20px);
    left: auto !important;
    right: 10px !important;
  }
}


  @media (max-width: 500px) {
    /* Sur mobile/tablette, garder le menu à droite */
    .custom-dropdown {
      right: 0 !important;
      left: auto !important;
    }
  }
/* Conteneur principal */
.ftco-section.ftco-no-pt {
  background: url('images/background-car.jpg') no-repeat center center;
  background-size: cover;
  position: relative;
}

/* Overlay sombre pour améliorer la lisibilité */
.ftco-section.ftco-no-pt::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
}

/* Modification du formulaire */
        /* Styles améliorés pour la section demande */
        .how-to-section {
            background: #f8f9fa;
            padding: 4rem 0;
        }
        
        .step-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            height: 100%;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s;
            border-left: 4px solid #2d73ed;
        }
        
        .step-card:hover {
            transform: translateY(-5px);
        }
        
        .step-icon {
            font-size: 2.5rem;
            color: #2d73ed;
            margin-bottom: 1rem;
        }
        
        /* Formulaire avec image de fond */
        .form-section {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('images/glecoupe.jpg') center/cover no-repeat;
            padding: 5rem 0;
            position: relative;
        }
        
        .request-form {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .request-form h2 {
            color: #2d73ed;
            margin-bottom: 25px;
            text-align: center;
            position: relative;
            padding-bottom: 15px;
        }
        
        .request-form h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: #2d73ed;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .request-form {
                padding: 20px;
            }
        }
    </style>
<!-- SECTION HERO -->
<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/cardealership.jpg');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
                <div class="col-md-9 ftco-animate pb-5">
                    <p class="breadcrumbs">
                        <span class="mr-2"><a href="index.html">Accueil <i class="ion-ios-arrow-forward"></i></a></span>
                        <span>Demande d'essai</span>
                    </p>
                    <h1 class="mb-3 bread">Demande d'essai</h1>
                    <p class="lead">Testez votre future voiture dans les meilleures conditions</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Section "Comment faire une demande" - Nouvelle position -->
    <section class="how-to-section">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-8 text-center">
                    <h2 class="mb-4">Comment réserver votre essai ?</h2>
                    <p>Procédure simple en 3 étapes pour tester votre véhicule</p>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="step-card">
                        <div class="step-icon">
                            <i class="fas fa-car"></i>
                        </div>
                        <h3>1. Choisissez votre véhicule</h3>
                        <p>Parcourez notre catalogue et sélectionnez le modèle qui vous intéresse.</p>
                        <a href="catalogue.php" class="btn btn-sm btn-outline-primary">Voir le catalogue</a>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="step-card">
                        <div class="step-icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <h3>2. Sélectionnez un créneau</h3>
                        <p>Choisissez le jour et l'heure qui vous conviennent pour votre essai.</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="step-card">
                        <div class="step-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h3>3. Confirmez votre essai</h3>
                        <p>Validez votre demande et recevez une confirmation par email.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- SECTION FORMULAIRE -->
<!-- Section Formulaire -->
<section class="form-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <form method="POST" action="trial.php" class="request-form ftco-animate">
                    <input type="hidden" name="id_voiture" value="<?= htmlspecialchars($id_voiture) ?>">
                        <h2>Réservez votre essai</h2>
                        <?php $id_voiture = isset($_GET['id_voiture']) ? (int)$_GET['id_voiture'] : 0; ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nom" class="label">Nom</label>
                                    <input type="text" class="form-control" id="nom" name="nom" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="prenom" class="label">Prénom</label>
                                    <input type="text" class="form-control" id="prenom" name="prenom" required>
                                </div>
                            </div>
                        </div>
                      <div class="row">
                           <div class="col-md-6">
                              <div class="form-group">
                                 <label for="email" class="label">Email</label>
                                 <input type="email" class="form-control" name="email" id="email" required 
                                   value="<?= htmlspecialchars($email) ?>" <?= $email ? 'readonly' : '' ?>>
                             </div>
                           </div>
                           <div class="col-md-6">
                                <div class="form-group">
                                    <label for="heurerecup" class="label">Heure de récupération</label>
                                    <input type="time" class="form-control" id="heurerecup" name="heurerecup" required>
                                </div>
                            </div>
                      </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="lieurecup" class="label">Lieu de récupération</label>
                                    <input type="text" class="form-control" id="lieurecup" name="lieurecup">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="lieudepot" class="label">Lieu de dépôt</label>
                                    <input type="text" class="form-control" id="lieudepot" name="lieudepot">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="daterecup" class="label">Date de récupération</label>
                                    <input type="date" class="form-control" id="daterecup" name="daterecup" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="daterecup" class="label">Date de dépot</label>
                                    <input type="date" class="form-control" id="datedepot" name="datedepot" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group text-center">
                            <button type="submit" id="trialRequestBtn" class="btn btn-primary py-3 px-5">
                                <span class="spinner-border spinner-border-sm d-none" id="trialSpinner"></span>
                                <span id="trialBtnText">Réserver mon essai</span>
                            </button>
                             <div id="trialMessage" class="alert d-none mt-3"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script>
        // Script amélioré pour la soumission du formulaire
        document.getElementById('trialRequestBtn').addEventListener('click', async function(e) {
    e.preventDefault();
    
    const btn = this;
    const spinner = document.getElementById('trialSpinner');
    const btnText = document.getElementById('trialBtnText');
    const messageDiv = document.getElementById('trialMessage');
    const form = document.querySelector('form');

    // Validation rapide
    let isValid = true;
    form.querySelectorAll('[required]').forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        }
    });

    if (!isValid) {
        messageDiv.textContent = 'Veuillez remplir tous les champs obligatoires';
        messageDiv.className = 'mt-3 alert alert-danger';
        return;
    }

    // Affichage du chargement
    spinner.classList.remove('d-none');
    btnText.textContent = 'Envoi...';
    btn.disabled = true;

    try {
        const startTime = Date.now(); // Mesure du temps
        const response = await fetch('trial.php', {
            method: 'POST',
            body: new FormData(form)
        });
        
        // Temps minimum d'affichage (1 seconde)
        const minDelay = 1000 - (Date.now() - startTime);
        if (minDelay > 0) await new Promise(resolve => setTimeout(resolve, minDelay));
        
        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || 'Erreur serveur');
        }

        // Affichage instantané du succès
        messageDiv.innerHTML = `
            <strong>✅ ${result.message}</strong>
            <div class="small">Référence: ${result.reservation_id}</div>
        `;
        messageDiv.className = 'mt-3 alert alert-success';
        
        // Réinitialisation douce
        btnText.textContent = 'Confirmation reçue';
        setTimeout(() => {
            messageDiv.classList.add('d-none');
            btn.disabled = false;
            btnText.textContent = 'Nouvelle réservation';
            form.reset();
        }, 6000);

    } catch (error) {
        messageDiv.textContent = '❌ ' + error.message;
        messageDiv.className = 'mt-3 alert alert-danger';
        btnText.textContent = 'Réessayer';
    } finally {
        spinner.classList.add('d-none');
    }
});
								</script>
								
	  					</div>

  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

 <footer style="
background: linear-gradient(135deg, #247eec, #12906c, #2d73ed);
color: white;
padding: 1.5rem 0;
text-align: center;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
position: relative;
margin-top: 3rem;
box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
">
<div style="
	max-width: 1200px;
	margin: 0 auto;
	padding: 0 20px;
">
	<p style="
		margin: 0;
		font-size: 1.1rem;
		letter-spacing: 1px;
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 10px;
		flex-wrap: wrap;
	">
		<span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>By Student MCCI</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>SIO</span>
	</p>
	
	<div style="
		margin-top: 1rem;
		display: flex;
		justify-content: center;
		gap: 1.5rem;
	">
		<a href="#contact.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-envelope"></i> Contact
		</a>
		<a href="#" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-shield-alt"></i> Confidentialité
		</a>
		<a href="#" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-file-alt"></i> Mentions légales
		</a>
	</div>
</div>
</footer>

  </body>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</html>
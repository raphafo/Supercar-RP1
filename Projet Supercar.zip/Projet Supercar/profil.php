<?php
session_start();

// Si l'utilisateur n'est pas connecté, on le redirige vers la page de connexion
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

// Connexion à la base de données
require_once 'db_connexion.php';

// Récupération des infos de l'utilisateur depuis la base
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT nom, prenom, email FROM inscription WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    echo "Utilisateur introuvable.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Profil utilisateur</title>
  <link rel="stylesheet" href="style.css"> <!-- ton style si tu en as un -->
</head>
<body>
  <div class="container" style="max-width: 600px; margin: 80px auto;">
    <h2>Bienvenue, <?= htmlspecialchars($user['prenom']) ?> 👋</h2>
    <div class="card" style="padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); border-radius: 10px;">
      <p><strong>Nom :</strong> <?= htmlspecialchars($user['nom']) ?></p>
      <p><strong>Prénom :</strong> <?= htmlspecialchars($user['prenom']) ?></p>
      <p><strong>Email :</strong> <?= htmlspecialchars($user['email']) ?></p>
    </div>
    <br>
    <a href="logout.php" class="btn btn-danger">Déconnexion</a>
  </div>
</body>
</html>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catalogue de Voitures</title>
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
 
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
		<div class="container-fluid px-0">
			<!-- Logo à gauche -->
			<a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">
				Super<span>car</span>
			</a>
			
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
				<span class="oi oi-menu"></span> Menu
			</button>
	
			<div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav mx-auto" style="max-width: 800px; width: 100%; display: flex; justify-content: center; flex-wrap: nowrap;">
                  <li class="nav-item"><a href="index.html" class="nav-link">Accueil</a></li>
                  <li class="nav-item"><a href="catalogue.php" class="nav-link">Voitures</a></li>
                  <li class="nav-item"><a href="demande.php" class="nav-link">Demande d’essai</a></li>
                  <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                  <li class="nav-item"><a href="contact.html" class="nav-link">Contactez-nous</a></li>
                </ul>
              
                <!-- Inscription à droite -->
                <?php
if (session_status() === PHP_SESSION_NONE) session_start();

$isConnected = isset($_SESSION['user_id']);
$nom = $isConnected && isset($_SESSION['user_nom']) ? $_SESSION['user_nom'] : 'Utilisateur';
$email = $isConnected && isset($_SESSION['email']) ? $_SESSION['email'] : '';
$initial = $isConnected ? strtoupper($nom[0]) : '';

?>
<style>
  .user-icon {
  position: relative;
  width: 45px;
  height: 45px;
  background-color:rgb(105, 119, 134);
  border-radius: 50%;
  color: white;
  font-size: 20px;
  text-align: center;
  line-height: 45px;
}


  .online-indicator {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 10px;
    height: 10px;
    background-color: #28a745;
    border: 2px solid white;
    border-radius: 50%;
  }

  @media (max-width: 991px) {
    .user-icon {
      margin-right: 0;
    }
  }
</style>

<a class="nav-link dropdown-toggle p-0 mr-3" href="#" id="userDropdown" role="button"
   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="position: relative;">
  <div class="user-icon d-flex align-items-center justify-content-center">
    <i class="fas fa-user"></i>
    <?php if ($isConnected): ?>
      <span class="online-indicator"></span>
    <?php endif; ?>
  </div>
</a>
    <div class="dropdown-menu dropdown-menu-right custom-dropdown profile-dropdown" aria-labelledby="userDropdown" style="min-width: 220px;">
      <?php if ($isConnected): ?>
        <span class="dropdown-item-text fw-bold"><?= $nom ?></span>
        <span class="dropdown-item-text text-muted small"><?= $email ?></span>
        <div class="dropdown-divider my-2"></div>
        <a class="dropdown-item text-danger small" href="logout.php">Se déconnecter</a>
      <?php else: ?>
        <a class="dropdown-item" href="connexion.php">Connexion</a>
        <a class="dropdown-item" href="inscription.php">Inscription</a>
      <?php endif; ?>
    </div>
  </li>
</ul>


 </div>
	</nav>
	
	<style>
		/* Ajustements pour le groupe de liens */
		@media (min-width: 992px) {
			.navbar-nav .nav-item[style*="inline-flex"] {
				display: inline-flex !important;
				align-items: center;
			}
			
			.navbar-brand {
				position: relative;
				left: -30px;
			}
			
			#ftco-nav {
				width: calc(100% - 100px);
			}
		}
		
		/* Version mobile */
		@media (max-width: 991px) {
			.navbar-nav .nav-item[style*="inline-flex"] {
				display: block !important;
			}
			
			.navbar-nav .nav-item[style*="inline-flex"] span {
				display: none;
			}
.dropdown-menu {
  right: auto !important;
  left: 0 !important;
  transform: none !important;
}

@media (max-width: 991px) {
  .dropdown-menu {
    right: 0 !important;
    left: auto !important;
  }
}
.profile-dropdown {
  padding: 10px 15px;
  border-radius: 12px;
  font-size: 14px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.profile-dropdown .dropdown-item-text {
  font-size: 13px;
  padding: 2px 0;
}

.profile-dropdown .dropdown-item {
  font-size: 13px;
  padding: 6px 0;
}

		}
	</style>
<style>
  .custom-dropdown {
    left: auto !important;
    right: 0 !important;
    transform: none !important;
  }

  @media (max-width: 500px) {
  .custom-dropdown {
    max-width: calc(100vw - 20px);
    left: auto !important;
    right: 10px !important;
  }
}


  @media (max-width: 500px) {
    /* Sur mobile/tablette, garder le menu à droite */
    .custom-dropdown {
      right: 0 !important;
      left: auto !important;
    }
  }
</style>
    </head>
    <body>
      <div class="container mt-5">
        <h1 class="mb-4 text-center">Catalogue de voitures</h1>
        <div class="row" id="car-list">
          <!-- Les voitures s'afficheront ici -->
        </div>
    
        <!-- Pagination -->
        <nav class="mt-4">
          <ul class="pagination justify-content-center" id="pagination">
            <!-- Pagination AJAX -->
          </ul>
        </nav>
      </div>
    
      <!-- Conteneur des modales -->
      <div id="modals-container"></div>
    
      <!-- Scripts -->
      <script>
    function loadCars(page = 1) {
        fetch(`get_voitures.php?page=${page}`)
            .then(res => {
                if (!res.ok) {
                    throw new Error('Network response was not ok');
                }
                return res.json();
            })
            .then(data => {
                const carList = document.getElementById("car-list");
                const modalsContainer = document.getElementById("modals-container");
                const pagination = document.getElementById("pagination");

                carList.innerHTML = "";
                modalsContainer.innerHTML = "";

                data.cars.forEach(car => {
                   // Texte de disponibilité
                let dispoText = car.disponible == 1 ? "✅ Disponible" : "❌ Non disponible";

                    carList.innerHTML += `
                        <div class="col-md-4 mb-4">
                            <div class="card">
                                <img src="${car.image}" class="card-img-top" alt="${car.marque}">
                                <div class="card-body">
                                    <h5 class="card-title">${car.marque}</h5>
                                    <p class="card-text"><strong>Année :</strong> ${car.annee}</p>
                                    <p class="card-text"><strong>Prix :</strong> ${car.prix} €</p>
                                    <p class="card-text"><strong>Disponibilité :</strong> ${dispoText}</p>
                                    <button class="btn btn-info" data-toggle="modal" data-target="#modal-${car.id}">Détails</button>
                                    <!-- Modification ici : Suppression de l'élément <a> et gestion du lien directement avec le bouton -->
                                    <button class="btn btn-primary essayer-btn" data-id="${car.id}">Essayer</button>
                                </div>
                            </div>
                        </div>
                    `;
                    modalsContainer.innerHTML += `
                        <div class="modal fade" id="modal-${car.id}" tabindex="-1" role="dialog" aria-labelledby="modalLabel-${car.id}" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalLabel-${car.id}">${car.marque} - ${car.annee}</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Fermer">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <img src="${car.image}" class="img-fluid mb-3" alt="${car.marque}">
                                        <p>${car.description}</p>
                                        <p><strong>Prix :</strong> ${car.prix} €/Jour</p>
                                        <p><strong>Disponibilité :</strong> ${dispoText}</p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });

                pagination.innerHTML = "";
                for (let i = 1; i <= data.totalPages; i++) {
                    pagination.innerHTML += `
                        <li class="page-item ${i === page ? 'active' : ''}">
                            <a class="page-link" href="#" onclick="loadCars(${i})">${i}</a>
                        </li>`;
                }
            })
            .catch(error => {
                console.error('Erreur lors du chargement des données:', error);
            });
    }

    document.addEventListener("DOMContentLoaded", () => loadCars());

document.addEventListener("click", function(e) {
  if (e.target?.classList.contains("essayer-btn")) {
    const voitureId = e.target.getAttribute("data-id");
    
    // Solution optimale avec gestion d'erreur complète
    fetch("check.php")
      .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
      })
      .then(data => {
        if (data.loggedIn) {
          // Redirection standard si connecté (peu importe emailExists)
          window.location.href = `demande.php?id_voiture=${voitureId}`;
        } else {
          // Redirection vers login avec conservation de l'ID
          window.location.href = `connexion.php?from=catalogue&car_id=${voitureId}`;
        }
      })
      .catch(err => {
        console.error("Erreur:", err);
        // Fallback basique si tout échoue
        window.location.href = `demande.php?id_voiture=${voitureId}`;
      });
  }
});
</script>
    </body>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    </html>



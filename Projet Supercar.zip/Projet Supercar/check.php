<?php
// Ne jamais rien mettre avant cette ligne
session_start();

header('Content-Type: application/json');

// Optionnel : désactiver les warnings HTML (utile en prod)
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_WARNING);

$response = [
    'loggedIn' => false,
    'emailExists' => false,
    'email' => null
];

try {
    if (!empty($_SESSION['user_id'])) {
        $response['loggedIn'] = true;
        $response['email'] = $_SESSION['user_email'] ?? null;

        // Vérifie si l'email existe dans la table `essai`
        if ($response['email']) {
            require 'db_connexion.php'; // Assure-toi que ce fichier crée $pdo
            $stmt = $pdo->prepare("SELECT 1 FROM essai WHERE email = ? LIMIT 1");
            $stmt->execute([$response['email']]);
            $response['emailExists'] = (bool)$stmt->fetch();
        }
    }

    echo json_encode($response);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur base de données']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur serveur']);
}
?>

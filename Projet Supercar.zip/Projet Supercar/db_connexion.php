<?php
$host = 'localhost';    // Serveur MySQL (WAMP utilise généralement 'localhost')
$dbname = 'supercar';  // Nom de votre base de données
$username = 'root';    // Utilisateur par défaut WAMP
$password = '';        // Mot de passe par défaut WAMP (vide)

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}
// Déterminer la page actuelle (si elle existe, sinon par défaut c'est la page 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 6;  // Nombre de voitures à afficher par page
$offset = ($page - 1) * $limit;  // Calcul de l'offset pour la pagination

// Récupérer les voitures avec LIMIT et OFFSET
// Récupérer les voitures avec LIMIT et OFFSET
$stmt = $pdo->prepare("SELECT * FROM voitures LIMIT :limit OFFSET :offset");
$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$cars = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Vérifier que les données ont bien été récupérées
// var_dump($cars); Vérifier le contenu de $cars


// Récupérer le nombre total de voitures pour la pagination
$totalCarsStmt = $pdo->query("SELECT COUNT(*) FROM voitures");
$totalCars = $totalCarsStmt->fetchColumn();
$totalPages = ceil($totalCars / $limit);  // Calcul du nombre total de pages
?>





<?php
session_start();
// Sécurité : seul un admin peut accéder
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

// Connexion BDD
$conn = new mysqli("localhost", "root", "", "supercar");
if ($conn->connect_error) die("Erreur DB : " . $conn->connect_error);

// === AJOUTER ===
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ajouter'])) {
    $titre = $_POST['titre'];
    $image = $_FILES['image']['name'];

    if (!empty($image)) {
        move_uploaded_file($_FILES['image']['tmp_name'], "../images/" . $image);
    }

    $stmt = $conn->prepare("INSERT INTO pieces (titre, image) VALUES (?, ?)");
    $stmt->bind_param("ss", $titre, $image);
    $stmt->execute();
    $stmt->close();

    header("Location: pieces_admin.php?msg=added");
    exit;
}

// === MODIFIER ===
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['modifier'])) {
    $id = intval($_POST['id']);
    $titre = $_POST['titre'];
    $image = $_FILES['image']['name'];

    if (!empty($image)) {
        move_uploaded_file($_FILES['image']['tmp_name'], "../images/" . $image);
        $stmt = $conn->prepare("UPDATE pieces SET titre=?, image=? WHERE id=?");
        $stmt->bind_param("ssi", $titre, $image, $id);
    } else {
        $stmt = $conn->prepare("UPDATE pieces SET titre=? WHERE id=?");
        $stmt->bind_param("si", $titre, $id);
    }
    $stmt->execute();
    $stmt->close();

    header("Location: pieces_admin.php?msg=updated");
    exit;
}

// === SUPPRIMER ===
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM pieces WHERE id=$id");
    header("Location: pieces_admin.php?msg=deleted");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Pièces</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="mb-4">Gestion des Pièces</h2>

    <!-- Formulaire d’ajout -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Ajouter une pièce</div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <input type="text" name="titre" placeholder="Titre (ex: batterie)" required class="form-control mb-2">
                <input type="file" name="image" required class="form-control mb-2">
                <button type="submit" name="ajouter" class="btn btn-success">Ajouter</button>
            </form>
        </div>
    </div>

    <!-- Tableau des actions -->
    <div class="card">
        <div class="card-header bg-dark text-white">Liste des actions</div>
        <div class="card-body">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Titre</th>
                        <th width="200">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $res = $conn->query("SELECT * FROM pieces ORDER BY id DESC");
                while ($row = $res->fetch_assoc()):
                ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><img src="../images/<?= $row['image'] ?>" width="100"></td>
                        <td><?= htmlspecialchars($row['titre']) ?></td>
                        <td>
                            <!-- Bouton modifier -->
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#editModal<?= $row['id'] ?>">Modifier</button>
                            <!-- Lien supprimer -->
                            <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger"
                               onclick="return confirm('Confirmer la suppression ?')">Supprimer</a>
                        </td>
                    </tr>

                    <!-- Modal de modification -->
                    <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form method="post" enctype="multipart/form-data">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Modifier action #<?= $row['id'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <div class="mb-3">
                                            <label class="form-label">Titre</label>
                                            <input type="text" name="titre" class="form-control"
                                                   value="<?= htmlspecialchars($row['titre']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Image (laisser vide pour ne pas changer)</label>
                                            <input type="file" name="image" class="form-control">
                                            <small>Image actuelle : <?= $row['image'] ?></small>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" name="modifier" class="btn btn-success">Enregistrer</button>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

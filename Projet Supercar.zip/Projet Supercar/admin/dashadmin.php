<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "supercar");
if ($conn->connect_error) die("Connexion échouée: " . $conn->connect_error);

$totalUsers = $conn->query("SELECT COUNT(*) AS total FROM inscription")->fetch_assoc()['total'];
$activeUsers = $conn->query("SELECT COUNT(*) AS active FROM inscription WHERE actif = 1")->fetch_assoc()['active'];
$totalDemandes = $conn->query("SELECT COUNT(*) AS demandes FROM essai")->fetch_assoc()['demandes'];
$totalVoitures = $conn->query("SELECT COUNT(*) AS voitures FROM voitures")->fetch_assoc()['voitures'];
$demandes = $conn->query("SELECT e.id, v.marque, i.nom, e.date_demande, e.statut FROM essai e JOIN voitures v ON e.id_voiture = v.id JOIN inscription i ON e.user_id = i.id ORDER BY e.date_demande DESC");
$voitures = $conn->query("SELECT * FROM voitures ORDER BY id DESC");
$users = $conn->query("SELECT * FROM inscription ORDER BY id DESC");
$pendingDemandes = $conn->query("SELECT COUNT(*) AS pending FROM essai WHERE statut = 'En attente'")->fetch_assoc()['pending'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - SuperCar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #2c3e50;
            color: white;
            transition: all 0.3s ease;
            box-shadow: 4px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 20px;
            background: #34495e;
            border-bottom: 1px solid #34495e;
        }

        .logo {
            display: flex;
            align-items: center;
            font-size: 1.4rem;
            font-weight: bold;
            color: #3498db;
        }

        .logo i {
            margin-right: 10px;
            font-size: 1.6rem;
        }

        .user-profile {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #34495e;
        }

        .user-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 0 auto 10px;
            object-fit: cover;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-item {
            padding: 12px 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
            display: flex;
            align-items: center;
        }

        .nav-item:hover {
            background: #34495e;
            border-left-color: #3498db;
        }

        .nav-item.active {
            background: #34495e;
            border-left-color: #3498db;
        }

        .nav-item i {
            margin-right: 15px;
            width: 20px;
            text-align: center;
        }

        .logout-item {
            margin-top: 50px;
            border-top: 1px solid #34495e;
            padding-top: 20px;
        }

        .logout-item a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .top-bar {
            background: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .search-box {
            display: flex;
            align-items: center;
            background: #f8f9fa;
            border-radius: 25px;
            padding: 8px 15px;
            width: 300px;
        }

        .search-box i {
            color: #6c757d;
            margin-right: 10px;
        }

        .search-box input {
            border: none;
            background: none;
            outline: none;
            flex: 1;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            cursor: pointer;
        }

        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* Stats Cards */

           .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

         .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--card-color, #3498db), var(--card-color-light, #74b9ff));
            transition: height 0.3s ease;
        }
        .stat-card:hover::before {
            height: 100%;
            opacity: 0.1;
        }

        .stat-card.primary { --card-color: #3498db; --card-color-light: #74b9ff; }
        .stat-card.success { --card-color: #27ae60; --card-color-light: #00b894; }
        .stat-card.warning { --card-color: #f39c12; --card-color-light: #fdcb6e; }
        .stat-card.info { --card-color: #17a2b8; --card-color-light: #6c5ce7; }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            background: var(--card-color);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }

        /* Content Sections */
        .content-section {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f8f9fa;
        }

        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c3e50;
            display: flex;
            align-items: center;
        }

        .section-title i {
            margin-right: 10px;
            color: #3498db;
        }

        .btn {
            background: linear-gradient(45deg, #3498db, #2980b9);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            font-size: 0.9rem;
            text-decoration: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
            color: white;
            text-decoration: none;
        }

        .btn i {
            margin-right: 8px;
        }

        .btn-success {
            background: linear-gradient(45deg, #27ae60, #229954);
        }

        .btn-warning {
            background: linear-gradient(45deg, #f39c12, #d68910);
        }

        .btn-danger {
            background: linear-gradient(45deg, #e74c3c, #c0392b);
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 0.8rem;
        }

        .btn-outline-primary {
            background: transparent;
            border: 2px solid #3498db;
            color: #3498db;
        }

        .btn-outline-primary:hover {
            background: #3498db;
            color: white;
        }

        /* Tables */
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        .data-table th,
        .data-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }

        .data-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
            position: sticky;
            top: 0;
        }

        .data-table tr:hover {
            background: #f8f9fa;
        }

        .status-badge {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .status-badge:hover {
            transform: scale(1.05);
        }

        .bg-warning {
            background: #fff3cd !important;
            color: #856404 !important;
        }

        .bg-primary {
            background: #cce5ff !important;
            color: #0056b3 !important;
        }

        .bg-success {
            background: #d4edda !important;
            color: #155724 !important;
        }

        .bg-secondary {
            background: #e2e6ea !important;
            color: #383d41 !important;
        }

        .bg-danger {
            background: #a00a17ff !important;
            color: #fcfcfcff !important;
        }

        /* Modal styles (if needed for future features) */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease;
        }

        @keyframes modalSlideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .hidden {
            display: none;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
                overflow: hidden;
            }
            
            .sidebar .nav-item span {
                display: none;
            }
            
            .search-box {
                width: 200px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .section-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }

        /* Quick actions */
        .quick-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        /* Animation pour les cartes stats */
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stat-card {
            animation: slideUp 0.6s ease forwards;
        }

        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }
        .stat-card:nth-child(4) { animation-delay: 0.4s; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
                    <div class="sidebar">
                        <div class="sidebar-header">
                            <div class="logo">
                                <i class="fas fa-car"></i>
                                <span>SuperCar</span>
                            </div>
                        </div>
                        
                        <div class="user-profile">
                            <div class="user-avatar" style="background: #3498db; width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px;">
                                <i class="fas fa-user-shield" style="color: white; font-size: 2rem;"></i>
                            </div>
                            <div><?= $_SESSION['username'] ?? 'Admin' ?></div>
                        </div>
                        
                        <nav class="nav-menu">
                            <div class="nav-item active" onclick="showSection('dashboard')">
                                <i class="fas fa-tachometer-alt"></i>
                                <span>Tableau de bord</span>
                            </div>
                            <div class="nav-item" onclick="showSection('users')">
                                <i class="fas fa-users"></i>
                                <span>Utilisateurs</span>
                            </div>
                            <div class="nav-item" onclick="showSection('cars')">
                                <i class="fas fa-car"></i>
                                <span>Voitures</span>
                            </div>
                            <div class="nav-item" onclick="showSection('bookings')">
                                <i class="fas fa-calendar-check"></i>
                                <span>Demandes d'essai (<?= $pendingDemandes ?>)</span>
                            </div>
                            <div class="nav-item">
                            <a href="services.php" style="color:inherit;text-decoration:none;">
                            <i class="fas fa-tools service-icon"></i>
                            <span>Services</span>
                            </a>
                            </div>
                              <div class="nav-item">
                            <a href="contact.php" style="color:inherit;text-decoration:none;">
                            <i class="fas fa-phone service-icon"></i>
                            <span>Contact</span>
                            </a>
                            </div>

                            <div class="nav-item" onclick="showSection('analytics')">
                                <i class="fas fa-chart-bar"></i>
                                <span>Analytics</span>
                            </div>
                            <div class="nav-item logout-item">
                                <a href="../logout.php">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <span>Déconnexion</span>
                                </a>
                            </div>
                        </nav>
                    </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Rechercher..." id="searchInput">
                </div>
                <div class="user-info">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="notification-count"><?= $totalDemandes ?></span>
                    </div>
                    <span>Bienvenue, <?= $_SESSION['username'] ?? 'Admin' ?></span>
                </div>
            </div>

            <!-- Dashboard Section -->
            <div id="dashboard-section" class="section">
                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card primary">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $totalUsers ?></div>
                        <div class="stat-label">Utilisateurs Inscrits</div>
                    </div>
                    
                    <div class="stat-card success">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-user-check"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $activeUsers ?></div>
                        <div class="stat-label">Utilisateurs Actifs</div>
                    </div>
                    
                    <div class="stat-card warning">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $totalDemandes ?></div>
                        <div class="stat-label">Demandes d'Essai</div>
                    </div>
                    
                    <div class="stat-card info">
                        <div class="stat-header">
                            <div class="stat-icon">
                                <i class="fas fa-car"></i>
                            </div>
                        </div>
                        <div class="stat-value"><?= $totalVoitures ?></div>
                        <div class="stat-label">Voitures Disponibles</div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-bolt"></i>
                            Actions Rapides
                        </h3>
                    </div>
                    <div class="quick-actions">
                        <a href="ajouter_voiture.php" class="btn">
                            <i class="fas fa-plus"></i> Ajouter Voiture
                        </a>
                        <a href="ajouter_utilisateur.php" class="btn btn-success">
                            <i class="fas fa-user-plus"></i> Nouvel Utilisateur
                        </a>
                        <button class="btn btn-warning" onclick="window.location.href='services.php'">
                            <i class="fas fa-file-export"></i> Gérer les Services
                        </button>
                    </div>
                </div>

                <!-- Vue d'ensemble récente -->
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-clock"></i>
                            Activité Récente
                        </h3>
                    </div>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Voiture</th>
                                    <th>Date</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                // Reset pointer for recent activity
                                $demandes = $conn->query("SELECT e.id, v.marque, i.nom, e.date_demande, e.statut FROM essai e JOIN voitures v ON e.id_voiture = v.id JOIN inscription i ON e.user_id = i.id ORDER BY e.date_demande DESC LIMIT 5");
                                while ($row = $demandes->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['nom']) ?></td>
                                        <td><?= htmlspecialchars($row['marque']) ?></td>
                                        <td><?= htmlspecialchars($row['date_demande']) ?></td>
                                        <td>
                                            <?php
                                            $badgeClass = match($row['statut']) {
                                                'En attente' => 'bg-warning text-dark',
                                                'En cours' => 'bg-primary text-white',
                                                'Terminé' => 'bg-success text-white',
                                                'Refusé' => 'bg-danger text-white', // Ajout pour rouge
                                                default => 'bg-secondary text-white'
                                            };
                                            ?>
                                            <span class="status-badge <?= $badgeClass ?>">
                                                <?= htmlspecialchars($row['statut']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Users Section -->
            <div id="users-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-users"></i>
                            Gestion des Utilisateurs
                        </h3>
                        <a href="ajouter_utilisateur.php" class="btn">
                            <i class="fas fa-plus"></i> Ajouter Utilisateur
                        </a>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="data-table" id="usersTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                    <th>Statut</th>
                                    <th>Date d'inscription</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $users = $conn->query("SELECT * FROM inscription ORDER BY id DESC");
                                while ($user = $users->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= str_pad($user['id'], 3, '0', STR_PAD_LEFT) ?></td>
                                        <td><?= htmlspecialchars($user['nom']) ?></td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td><?= htmlspecialchars($user['role']) ?></td>
                                        <td>
                                            <span class="status-badge <?= $user['actif'] ? 'bg-success text-white' : 'bg-warning text-dark' ?>">
                                                <?= $user['actif'] ? 'Actif' : 'Inactif' ?>
                                            </span>
                                        </td>
                                        <td><?= date('d/m/Y', strtotime($user['date_inscription'] ?? 'now')) ?></td>
                                        <td>
                                            <a href="modifier_utilisateur.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="supprimer_utilisateur.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression ?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Cars Section -->
            <div id="cars-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-car"></i>
                            Gestion des Voitures
                        </h3>
                        <a href="ajouter_voiture.php" class="btn">
                            <i class="fas fa-plus"></i> Ajouter Voiture
                        </a>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="data-table" id="carsTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Marque</th>
                                    <th>Année</th>
                                    <th>Prix</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $voitures = $conn->query("SELECT * FROM voitures ORDER BY id DESC");
                                while ($car = $voitures->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= str_pad($car['id'], 3, '0', STR_PAD_LEFT) ?></td>
                                        <td><?= htmlspecialchars($car['marque']) ?></td>
                                        <td><?= htmlspecialchars($car['annee']) ?></td>
                                        <td><?= number_format($car['prix'], 0, ',', ' ') ?> €</td>
                                        <td><?= htmlspecialchars(substr($car['description'], 0, 50)) ?>...</td>
                                        <td>
                                            <?php if ($car['image']): ?>
                                                <img src="../<?= htmlspecialchars($car['image']) ?>" alt="Voiture" width="120">
                                            <?php else: ?>
                                                Pas d'image
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="modifier_voiture.php?id=<?= $car['id'] ?>" class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="supprimer_voiture.php?id=<?= $car['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Confirmer la suppression ?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Bookings Section -->
            <div id="bookings-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-calendar-check"></i>
                            Demandes d'Essai
                        </h3>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="data-table" id="bookingsTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Client</th>
                                    <th>Voiture</th>
                                    <th>Date demande</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $demandes = $conn->query("SELECT e.id, v.marque, i.nom, e.date_demande, e.statut FROM essai e JOIN voitures v ON e.id_voiture = v.id JOIN inscription i ON e.user_id = i.id ORDER BY e.date_demande DESC");
                                while ($row = $demandes->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= str_pad($row['id'], 3, '0', STR_PAD_LEFT) ?></td>
                                        <td><?= htmlspecialchars($row['nom']) ?></td>
                                        <td><?= htmlspecialchars($row['marque']) ?></td>
                                        <td><?= htmlspecialchars($row['date_demande']) ?></td>
                                        <td>
                                            <?php
                                            $badgeClass = match($row['statut']) {
                                                'En attente' => 'bg-warning text-dark',
                                                'En cours' => 'bg-primary text-white',
                                                'Terminé' => 'bg-success text-white',
                                                'Refusé' => 'bg-danger text-white', // Ajout pour rouge
                                                default => 'bg-secondary text-white'
                                            };
                                            ?>
                                            <?php if ($row['statut'] === 'En cours'): ?>
        <form method="POST" action="changer_statut.php" style="display:inline;">
            <input type="hidden" name="id_essai" value="<?= $row['id'] ?>">
            <input type="hidden" name="statut_actuel" value="<?= $row['statut'] ?>">
            <button type="submit" class="status-badge <?= $badgeClass ?>" title="Passer à Terminé">
                <?= htmlspecialchars($row['statut']) ?>
            </button>
        </form>
    <?php else: ?>
        <span class="status-badge <?= $badgeClass ?>">
            <?= htmlspecialchars($row['statut']) ?>
        </span>
    <?php endif; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-success" onclick="approveBooking(<?= $row['id'] ?>)">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="rejectBooking(<?= $row['id'] ?>)">
                                                <i class="fas fa-times"></i>
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="deleteBooking(<?= $row['id'] ?>)" title="Supprimer">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Analytics Section -->
            <div id="analytics-section" class="section hidden">
                <div class="content-section">
                    <div class="section-header">
                        <h3 class="section-title">
                            <i class="fas fa-chart-bar"></i>
                            Analytics & Rapports
                        </h3>
                    </div>
                    
                    <!-- Stats détaillées -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="stat-card primary">
                                <div class="stat-header">
                                    <div class="stat-icon">
                                        <i class="fas fa-chart-line"></i>
                                    </div>
                                </div>
                                <div class="stat-value">
                                    <?php 
                                    $ratio = $activeUsers > 0 ? round(($activeUsers / $totalUsers) * 100, 1) : 0;
                                    echo $ratio . '%';
                                    ?>
                                </div>
                                <div class="stat-label">Taux d'activation utilisateurs</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stat-card warning">
                                <div class="stat-header">
                                    <div class="stat-icon">
                                        <i class="fas fa-calendar-week"></i>
                                    </div>
                                </div>
                                <div class="stat-value">
                                    <?php 
                                    $weeklyBookings = $conn->query("SELECT COUNT(*) as count FROM essai WHERE date_demande >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'];
                                    echo $weeklyBookings;
                                    ?>
                                </div>
                                <div class="stat-label">Demandes cette semaine</div>
                            </div>
                        </div>
                    </div>

                    <!-- Tableau de bord analytique -->
                    <div style="background: #f8f9fa; padding: 40px; border-radius: 10px; text-align: center;">
                        <i class="fas fa-chart-pie fa-3x" style="color: #6c757d; margin-bottom: 20px;"></i>
                        <h4 style="color: #6c757d;">Graphiques Analytiques</h4>
                        <p style="color: #6c757d;">Intégration avec Chart.js ou D3.js recommandée</p>
                        <div style="margin-top: 20px;">
                            <button class="btn btn-outline-primary" onclick="generateReport()">
                                <i class="fas fa-file-pdf"></i> Générer Rapport PDF
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Variables globales
        let currentSection = 'dashboard';

        // Navigation entre sections
        function showSection(sectionName) {
            // Masquer toutes les sections
            document.querySelectorAll('.section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Retirer la classe active de tous les nav-items
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Afficher la section demandée
            document.getElementById(sectionName + '-section').classList.remove('hidden');
            
            // Ajouter la classe active au nav-item cliqué
            event.target.closest('.nav-item').classList.add('active');
            
            currentSection = sectionName;
        }

        // Fonction de recherche
        function searchTable() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            let targetTable;
            
            // Déterminer quelle table rechercher en fonction de la section active
            switch(currentSection) {
                case 'users':
                    targetTable = document.getElementById('usersTable');
                    break;
                case 'cars':
                    targetTable = document.getElementById('carsTable');
                    break;
                case 'bookings':
                    targetTable = document.getElementById('bookingsTable');
                    break;
                default:
                    return;
            }
            
            if (!targetTable) return;
            
            const rows = targetTable.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        }

        // Ajouter l'événement de recherche
        document.getElementById('searchInput').addEventListener('input', searchTable);

        // Fonctions pour les actions sur les demandes d'essai
        function approveBooking(bookingId) {
            if (confirm('Approuver cette demande d\'essai ?')) {
                // Créer un formulaire pour envoyer la requête
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'approve_booking.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'booking_id';
                input.value = bookingId;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function rejectBooking(bookingId) {
            if (confirm('Rejeter cette demande d\'essai ?')) {
                // Créer un formulaire pour envoyer la requête
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'reject_booking.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'booking_id';
                input.value = bookingId;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }

        function deleteBooking(bookingId) {
            if (confirm('Supprimer cette demande d\'essai ?')) {
                // Créer un formulaire pour envoyer la requête
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'delete_booking.php';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'booking_id';
                input.value = bookingId;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }



        // Fonction de génération de rapport
        function generateReport() {
            const reportUrl = 'generate_report.php';
            window.open(reportUrl, '_blank');
            showNotification('Génération du rapport en cours...', 'info');
        }

        // Système de notifications
        function showNotification(message, type = 'info') {
            // Supprimer les notifications existantes
            const existingNotifications = document.querySelectorAll('.notification');
            existingNotifications.forEach(notif => notif.remove());

            const notification = document.createElement('div');
            notification.className = 'notification';
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : type === 'warning' ? '#f39c12' : '#3498db'};
                color: white;
                padding: 15px 25px;
                border-radius: 8px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                z-index: 10000;
                animation: slideInRight 0.3s ease;
                max-width: 350px;
                word-wrap: break-word;
            `;
            
            // Ajouter une icône basée sur le type
            const icon = type === 'success' ? 'fa-check-circle' : 
                        type === 'error' ? 'fa-times-circle' : 
                        type === 'warning' ? 'fa-exclamation-triangle' : 
                        'fa-info-circle';
            
            notification.innerHTML = `
                <i class="fas ${icon}" style="margin-right: 10px;"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            // Auto-remove après 4 secondes
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }, 4000);
        }

        // Animations CSS pour les notifications
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { 
                    transform: translateX(100%); 
                    opacity: 0; 
                }
                to { 
                    transform: translateX(0); 
                    opacity: 1; 
                }
            }
            @keyframes slideOutRight {
                from { 
                    transform: translateX(0); 
                    opacity: 1; 
                }
                to { 
                    transform: translateX(100%); 
                    opacity: 0; 
                }
            }
            
            /* Améliorer le responsive */
            @media (max-width: 768px) {
                .stats-grid {
                    grid-template-columns: 1fr;
                }
                .quick-actions {
                    flex-direction: column;
                }
                .section-header {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 15px;
                }
                .data-table {
                    font-size: 0.9rem;
                }
                .data-table th,
                .data-table td {
                    padding: 10px 8px;
                }
            }
            
            /* Style pour les boutons de statut actifs */
            .status-badge:active {
                transform: scale(0.95);
            }
            
            /* Améliorer l'accessibilité */
            .nav-item:focus,
            .btn:focus,
            .status-badge:focus {
                outline: 2px solid #3498db;
                outline-offset: 2px;
            }
        `;
        document.head.appendChild(style);

        // Auto-actualisation des données (optionnel)
        function autoRefresh() {
            // Actualiser uniquement les statistiques
            fetch('get_stats.php')
                .then(response => response.json())
                .then(data => {
                    // Mettre à jour les valeurs des cartes statistiques
                    if (data.success) {
                        document.querySelector('.stat-card.primary .stat-value').textContent = data.totalUsers;
                        document.querySelector('.stat-card.success .stat-value').textContent = data.activeUsers;
                        document.querySelector('.stat-card.warning .stat-value').textContent = data.totalDemandes;
                        document.querySelector('.stat-card.info .stat-value').textContent = data.totalVoitures;
                        document.querySelector('.notification-count').textContent = data.totalDemandes;
                    }
                })
                .catch(error => console.log('Erreur lors de la mise à jour:', error));
        }

        // Actualiser les stats toutes les 5 minutes
        setInterval(autoRefresh, 300000);

        // Gestion des erreurs PHP (si des messages sont passés via session)
        <?php if (isset($_SESSION['success_message'])): ?>
            showNotification('<?= $_SESSION['success_message'] ?>', 'success');
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            showNotification('<?= $_SESSION['error_message'] ?>', 'error');
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        // Initialisation
        document.addEventListener('DOMContentLoaded', function() {
            // Animation d'entrée pour les cartes
            const cards = document.querySelectorAll('.stat-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                    card.style.transition = 'all 0.6s ease';
                }, index * 100);
            });

            // Afficher une notification de bienvenue
            setTimeout(() => {
                showNotification('Bienvenue dans votre dashboard SuperCar !', 'success');
            }, 1000);
        });

        // Raccourcis clavier
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + K pour focus sur la recherche
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                document.getElementById('searchInput').focus();
            }
            
            // Échap pour effacer la recherche
            if (e.key === 'Escape') {
                document.getElementById('searchInput').value = '';
                searchTable();
            }
        });
    </script>

    <?php $conn->close(); ?>
</body>
</html>

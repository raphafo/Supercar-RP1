<?php
session_start(); // Toujours en haut

// Connexion à la base de données (mysqli)
$host = "localhost";
$login = "root";
$pass = "";
$dbname = "supercar";
$conn = new mysqli($host, $login, $pass, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}
// Récupérer l'ID de la voiture
$voiture_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($voiture_id <= 0) {
    $_SESSION['error_message'] = 'ID voiture invalide.';
    header('Location: dashadmin.php');
    exit;
}

// Récupérer les informations de la voiture
$stmt = $conn->prepare("SELECT * FROM voitures WHERE id = ?");
$stmt->bind_param("i", $voiture_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error_message'] = 'Voiture non trouvée.';
    header('Location: dashadmin.php');
    exit;
}

$voiture = $result->fetch_assoc();

// Traitement de la suppression
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirmer_suppression'])) {
    // Vérifier si la voiture a des réservations ou essais en cours
    $check_demandes = $conn->prepare("SELECT COUNT(*) as count FROM essai WHERE id_voiture = ? AND statut IN ('en_attente', 'confirmee')");
    if ($check_demandes) {
        $check_demandes->bind_param("i", $voiture_id);
        $check_demandes->execute();
        $demandes_result = $check_demandes->get_result();
        $demandes_count = $demandes_result->fetch_assoc()['count'];

        if ($demandes_count > 0) {
            $_SESSION['error_message'] = 'Impossible de supprimer cette voiture car elle a des réservations en cours.';
            header('Location: dashadmin.php');
            exit;
        }
    }
    
    // Supprimer l'image si elle existe
    if ($voiture['image'] && file_exists($voiture['image'])) {
        unlink($voiture['image']);
    }
    
    // Procéder à la suppression
    $delete_stmt = $conn->prepare("DELETE FROM voitures WHERE id = ?");
    $delete_stmt->bind_param("i", $voiture_id);
    
    if ($delete_stmt->execute()) {
        $_SESSION['success_message'] = 'Voiture supprimée avec succès.';
        header('Location: dashadmin.php');
        exit;
    } else {
        $_SESSION['error_message'] = 'Erreur lors de la suppression : ' . $conn->error;
        header('Location: dashadmin.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer la Voiture - SuperCar Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .card-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .card-header p {
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .card-body {
            padding: 40px;
        }

        .warning-box {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-left: 5px solid #ffc107;
            color: #856404;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
        }

        .warning-box i {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .voiture-info {
            background-color: #f8f9fa;
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid #dc3545;
        }

        .voiture-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .voiture-image {
            width: 150px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #e1e5e9;
        }

        .voiture-image-placeholder {
            width: 150px;
            height: 100px;
            background-color: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            border: 2px solid #e1e5e9;
        }

        .voiture-title h4 {
            color: #dc3545;
            margin-bottom: 5px;
            font-size: 1.3rem;
        }

        .voiture-title p {
            color: #666;
            font-size: 0.95rem;
        }

        .voiture-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .detail-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .detail-item:last-child {
            border-bottom: none;
        }

        .detail-label {
            font-weight: 600;
            color: #666;
        }

        .detail-value {
            color: #333;
        }

        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .bg-success {
            background-color: #28a745;
            color: white;
        }

        .bg-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-right: 15px;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(220, 53, 69, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #dc3545;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #c82333;
        }

        .action-buttons {
            margin-top: 30px;
            text-align: center;
        }

        .price-highlight {
            font-size: 1.2rem;
            font-weight: bold;
            color: #28a745;
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                padding: 0 15px;
            }
            
            .card-body {
                padding: 25px;
            }

            .voiture-header {
                flex-direction: column;
                text-align: center;
            }

            .voiture-details {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashadmin.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
            Retour au tableau de bord
        </a>

        <div class="card">
            <div class="card-header">
                <h1><i class="fas fa-car-crash"></i> Supprimer la Voiture</h1>
                <p>Confirmation de suppression</p>
            </div>

            <div class="card-body">
                <div class="warning-box">
                    <div style="text-align: center;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3 style="margin-bottom: 10px;">Attention !</h3>
                        <p>Cette action est <strong>irréversible</strong>. Cette voiture sera définitivement supprimée de votre inventaire.</p>
                    </div>
                </div>

                <div class="voiture-info">
                    <div class="voiture-header">
                        <?php if ($voiture['image'] && file_exists($voiture['image'])): ?>
                            <img src="<?= htmlspecialchars($voiture['image']) ?>" alt="<?= htmlspecialchars($voiture['marque']) ?>" class="voiture-image">
                        <?php else: ?>
                            <div class="voiture-image-placeholder">
                                <i class="fas fa-car" style="font-size: 2rem; color: #6c757d;"></i>
                            </div>
                        <?php endif; ?>
                        
                        <div class="voiture-title">
                            <h4><i class="fas fa-car"></i> <?= htmlspecialchars($voiture['marque'])?></h4>
                            <p>ID: #<?= str_pad($voiture['id'], 3, '0', STR_PAD_LEFT) ?> | Année: <?= $voiture['annee'] ?></p>
                            <p class="price-highlight"><?= number_format($voiture['prix'], 0, ',', ' ') ?> €</p>
                        </div>
                    </div>

                    <div class="voiture-details">
                            <div class="detail-item">
                                <span class="detail-label">Disponibilité :</span>
                                <span class="detail-value">
                                    <span class="status-badge <?= $voiture['disponible'] ? 'bg-success' : 'bg-danger' ?>">
                                        <?= $voiture['disponible'] ? 'Disponible' : 'Non disponible' ?>
                                    </span>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($voiture['description'])): ?>
                        <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
                            <strong>Description :</strong>
                            <p style="margin-top: 5px; color: #666;"><?= htmlspecialchars($voiture['description']) ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="warning-box" style="text-align: center;">
                    <p><strong>Êtes-vous absolument certain de vouloir supprimer cette voiture ?</strong></p>
                    <p style="margin-top: 10px; font-size: 0.9rem;">Cette action supprimera définitivement :</p>
                    <ul style="margin-top: 10px; text-align: left; display: inline-block;">
                        <li>La fiche de la voiture</li>
                        <li>L'image associée (si présente)</li>
                        <li>Toutes les informations techniques</li>
                        <li>L'historique des modifications</li>
                    </ul>
                </div>

                <div class="action-buttons">
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="confirmer_suppression" value="1">
                        <button type="submit" class="btn btn-danger" onclick="return confirm('DERNIÈRE CONFIRMATION : Êtes-vous vraiment sûr de vouloir supprimer définitivement cette voiture ?')">
                            <i class="fas fa-trash"></i>
                            Oui, supprimer définitivement
                        </button>
                    </form>
                    
                    <a href="dashadmin.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Non, annuler
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

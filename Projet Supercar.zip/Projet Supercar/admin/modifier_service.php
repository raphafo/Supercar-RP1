<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") exit("unauthorized");

$conn = new mysqli("localhost", "root", "", "supercar");
if ($conn->connect_error) exit("db_error");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $titre = $_POST['titre'] ?? '';
    $icone = $_POST['icone'] ?? '';
    $description = $_POST['description'] ?? '';
    $lien = $_POST['lien'] ?? '';
    $type = $_POST['type'] ?? '';
    $details = $_POST['details'] ?? '';

    $stmt = $conn->prepare("UPDATE services SET titre=?, icone=?, description=?, lien=?, type=?, details=? WHERE id=?");
    $stmt->bind_param("ssssssi", $titre, $icone, $description, $lien, $type, $details, $id);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }
    $stmt->close();
    $conn->close();
    exit;
}
echo "invalid";
$conn->close();
?>

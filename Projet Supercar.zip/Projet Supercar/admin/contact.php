<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

$host = "localhost";
$login = "root";
$pass = "";
$bdd = "supercar";

// Connexion à la base de données
$conn = new mysqli($host, $login, $pass, $bdd);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Vérifier et ajouter la colonne date_envoi si elle n'existe pas
$check_column_query = "SHOW COLUMNS FROM contactez LIKE 'date_envoi'";
$result = $conn->query($check_column_query);

if ($result->num_rows == 0) {
    // La colonne n'existe pas, on l'ajoute
    $alter_table_query = "ALTER TABLE contactez ADD date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP";
    if ($conn->query($alter_table_query)) {
        $_SESSION['message'] = "Colonne date_envoi ajoutée avec succès.";
    } else {
        $_SESSION['error'] = "Erreur lors de l'ajout de la colonne: " . $conn->error;
    }
}

// Traitement des actions (marquer comme traité/supprimer)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action'])) {
        $id = intval($_POST['id']);
        
        if ($_POST['action'] === 'traiter') {
            $stmt = $conn->prepare("UPDATE contactez SET traite = 1 WHERE idclient = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            $_SESSION['message'] = "Message marqué comme traité.";
        } 
        elseif ($_POST['action'] === 'supprimer') {
            $stmt = $conn->prepare("DELETE FROM contactez WHERE idclient = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            $_SESSION['message'] = "Message supprimé avec succès.";
        }
    }
    
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Récupération des messages
$query = "SELECT * FROM contactez ORDER BY date_envoi DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - Messages Supercar</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background: linear-gradient(135deg, #2c3e50, #1a2530);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .notification {
            padding: 10px 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            background-color: #4CAF50;
            color: white;
        }
        
        .error {
            padding: 10px 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            background-color: #f44336;
            color: white;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .stat-card h3 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: #2c3e50;
        }
        
        .messages-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .messages-table th, 
        .messages-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        .messages-table th {
            background-color: #2c3e50;
            color: white;
            font-weight: 600;
        }
        
        .messages-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .messages-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .traite {
            background-color: #e8f5e9 !important;
        }
        
        .btn {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        
        .btn-traiter {
            background-color: #4CAF50;
            color: white;
        }
        
        .btn-traiter:hover {
            background-color: #3e8e41;
        }
        
        .btn-supprimer {
            background-color: #f44336;
            color: white;
        }
        
        .btn-supprimer:hover {
            background-color: #d32f2f;
        }
        
        .btn-deconnecter {
            background-color: #ff9800;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 4px;
            display: inline-block;
            margin-top: 20px;
        }
        
        .btn-deconnecter:hover {
            background-color: #e68900;
        }
        
        .action-form {
            display: inline;
        }
        
        .empty-message {
            text-align: center;
            padding: 40px;
            color: #777;
        }
        
        @media (max-width: 768px) {
            .messages-table {
                display: block;
                overflow-x: auto;
            }
            
            .stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <header>
            <h1>🛠️ Administration Supercar - Messages Reçus</h1>
            <p>Gérez les messages envoyés via le formulaire de contact</p>
        </header>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="notification">
                <?php 
                echo $_SESSION['message']; 
                unset($_SESSION['message']);
                ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error">
                <?php 
                echo $_SESSION['error']; 
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>
        
        <div class="stats">
            <?php
            // Compter les messages non traités
            $query_non_traites = "SELECT COUNT(*) as count FROM contactez WHERE traite = 0 OR traite IS NULL";
            $result_non_traites = $conn->query($query_non_traites);
            $non_traites = $result_non_traites->fetch_assoc()['count'];
            ?>
            
            <div class="stat-card">
                <h3><?php echo $result->num_rows; ?></h3>
                <p>Messages au total</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo $non_traites; ?></h3>
                <p>Messages non traités</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo $result->num_rows - $non_traites; ?></h3>
                <p>Messages traités</p>
            </div>
        </div>
        
        <table class="messages-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Sujet</th>
                    <th>Message</th>
                    <th>Date d'envoi</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr class="<?php echo (isset($row['traite']) && $row['traite']) ? 'traite' : ''; ?>">
                            <td><?php echo $row['idclient']; ?></td>
                            <td><?php echo htmlspecialchars($row['nom']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['sujet']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                            <td>
                                <?php 
                                if (isset($row['date_envoi']) && $row['date_envoi']) {
                                    echo date('d/m/Y H:i', strtotime($row['date_envoi']));
                                } else {
                                    echo "Non définie";
                                }
                                ?>
                            </td>
                            <td>
                                <?php if (!isset($row['traite']) || !$row['traite']): ?>
                                    <form class="action-form" method="post">
                                        <input type="hidden" name="id" value="<?php echo $row['idclient']; ?>">
                                        <input type="hidden" name="action" value="traiter">
                                        <button type="submit" class="btn btn-traiter">Marquer comme traité</button>
                                    </form>
                                <?php endif; ?>
                                
                                <form class="action-form" method="post" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce message ?');">
                                    <input type="hidden" name="id" value="<?php echo $row['idclient']; ?>">
                                    <input type="hidden" name="action" value="supprimer">
                                    <button type="submit" class="btn btn-supprimer">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="empty-message">Aucun message reçu pour le moment.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <a href="dashadmin.php" class="btn-deconnecter">Retour au dashboard</a>
    </div>
</body>
</html>

<?php
$conn->close();
?>
<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $id = intval($_POST['booking_id']);
    $conn = new mysqli("localhost", "root", "", "supercar");
    if ($conn->connect_error) die("Connexion échouée: " . $conn->connect_error);

    $stmt = $conn->prepare("UPDATE essai SET statut = 'En cours' WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Demande d'essai approuvée avec succès.";
    } else {
        $_SESSION['error_message'] = "Erreur lors de l'approbation.";
    }
    $stmt->close();
    $conn->close();
} else {
    $_SESSION['error_message'] = "Requête invalide.";
}
header("Location: dashadmin.php#bookings-section");
exit();
<?php
session_start(); // Toujours en haut

// Connexion à la base de données (mysqli)
$host = "localhost";
$login = "root";
$pass = "";
$dbname = "supercar";
$conn = new mysqli($host, $login, $pass, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Récupérer l'ID de l'utilisateur
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id <= 0) {
    $_SESSION['error_message'] = 'ID utilisateur invalide.';
    header('Location: dashadmin.php');
    exit;
}

// Récupérer les informations de l'utilisateur
$stmt = $conn->prepare("SELECT * FROM inscription WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error_message'] = 'Utilisateur non trouvé.';
    header('Location: dashadmin.php');
    exit;
}

$user = $result->fetch_assoc();

// Traitement de la suppression
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirmer_suppression'])) {
    // Vérifier si l'utilisateur a des réservations ou essais en cours
    // (Optionnel : adaptez selon votre structure de base)
    $check_demandes = $conn->prepare("SELECT COUNT(*) as count FROM essai WHERE user_id = ? AND statut IN ('en_attente', 'confirmee')");
    if ($check_demandes) {
        $check_demandes->bind_param("i", $user_id);
        $check_demandes->execute();
        $demandes_result = $check_demandes->get_result();
        $demandes_count = $demandes_result->fetch_assoc()['count'];

        if ($demandes_count > 0) {
            $_SESSION['error_message'] = 'Impossible de supprimer cet utilisateur car il a des demandes en cours.';
            header('Location: dashadmin.php');
            exit;
        }
    }
    
    // Procéder à la suppression
    $delete_stmt = $conn->prepare("DELETE FROM inscription WHERE id = ?");
    $delete_stmt->bind_param("i", $user_id);
    
    if ($delete_stmt->execute()) {
        $_SESSION['success_message'] = 'Utilisateur supprimé avec succès.';
        header('Location: dashadmin.php');
        exit;
    } else {
        $_SESSION['error_message'] = 'Erreur lors de la suppression : ' . $conn->error;
        header('Location: dashadmin.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer l'Utilisateur - SuperCar Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .card-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .card-header p {
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .card-body {
            padding: 40px;
        }

        .warning-box {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-left: 5px solid #ffc107;
            color: #856404;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
        }

        .warning-box i {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .user-info {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid #dc3545;
        }

        .user-detail {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }

        .user-detail:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .user-detail .label {
            font-weight: 600;
            color: #666;
        }

        .user-detail .value {
            color: #333;
        }

        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .bg-primary {
            background-color: #007bff;
            color: white;
        }

        .bg-info {
            background-color: #17a2b8;
            color: white;
        }

        .bg-success {
            background-color: #28a745;
            color: white;
        }

        .bg-warning {
            background-color: #ffc107;
            color: #333;
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-right: 15px;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background-color: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(220, 53, 69, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #dc3545;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #c82333;
        }

        .action-buttons {
            margin-top: 30px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px auto;
                padding: 0 15px;
            }
            
            .card-body {
                padding: 25px;
            }

            .user-detail {
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashadmin.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
            Retour au tableau de bord
        </a>

        <div class="card">
            <div class="card-header">
                <h1><i class="fas fa-user-times"></i> Supprimer l'Utilisateur</h1>
                <p>Confirmation de suppression</p>
            </div>

            <div class="card-body">
                <div class="warning-box">
                    <div style="text-align: center;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3 style="margin-bottom: 10px;">Attention !</h3>
                        <p>Cette action est <strong>irréversible</strong>. Toutes les données de cet utilisateur seront définitivement supprimées.</p>
                    </div>
                </div>

                <div class="user-info">
                    <h4 style="color: #dc3545; margin-bottom: 15px;">
                        <i class="fas fa-user"></i>
                        Informations de l'utilisateur à supprimer
                    </h4>
                    
                    <div class="user-detail">
                        <span class="label">ID :</span>
                        <span class="value">#<?= str_pad($user['id'], 3, '0', STR_PAD_LEFT) ?></span>
                    </div>
                    
                    <div class="user-detail">
                        <span class="label">Nom complet :</span>
                        <span class="value"><?= htmlspecialchars($user['nom'] . ' ' . $user['prenom']) ?></span>
                    </div>
                    
                    <div class="user-detail">
                        <span class="label">Email :</span>
                        <span class="value"><?= htmlspecialchars($user['email']) ?></span>
                    </div>
                    
                    <div class="user-detail">
                        <span class="label">Ville :</span>
                        <span class="value"><?= htmlspecialchars($user['ville'] ?? 'Non renseignée') ?></span>
                    </div>
                    
                    <div class="user-detail">
                        <span class="label">Rôle :</span>
                        <span class="value">
                            <span class="status-badge <?= $user['role'] == 'admin' ? 'bg-primary' : 'bg-info' ?>">
                                <?= $user['role'] == 'admin' ? 'Administrateur' : 'Utilisateur' ?>
                            </span>
                        </span>
                    </div>
                    
                    <div class="user-detail">
                        <span class="label">Statut :</span>
                        <span class="value">
                            <span class="status-badge <?= $user['actif'] ? 'bg-success' : 'bg-warning' ?>">
                                <?= $user['actif'] ? 'Actif' : 'Inactif' ?>
                            </span>
                        </span>
                    </div>
                    
                    <div class="user-detail">
                        <span class="label">Inscrit le :</span>
                        <span class="value"><?= date('d/m/Y à H:i', strtotime($user['date_inscription'] ?? 'now')) ?></span>
                    </div>
                </div>

                <div class="warning-box" style="text-align: center;">
                    <p><strong>Êtes-vous absolument certain de vouloir supprimer cet utilisateur ?</strong></p>
                    <p style="margin-top: 10px; font-size: 0.9rem;">Cette action supprimera définitivement :</p>
                    <ul style="margin-top: 10px; text-align: left; display: inline-block;">
                        <li>Le compte utilisateur</li>
                        <li>Toutes ses informations personnelles</li>
                        <li>L'historique de ses connexions</li>
                    </ul>
                </div>

                <div class="action-buttons">
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="confirmer_suppression" value="1">
                        <button type="submit" class="btn btn-danger" onclick="return confirm('DERNIÈRE CONFIRMATION : Êtes-vous vraiment sûr de vouloir supprimer définitivement cet utilisateur ?')">
                            <i class="fas fa-trash"></i>
                            Oui, supprimer définitivement
                        </button>
                    </form>
                    
                    <a href="dashadmin.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Non, annuler
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
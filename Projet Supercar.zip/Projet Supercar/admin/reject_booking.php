<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $id = intval($_POST['booking_id']);
    $conn = new mysqli("localhost", "root", "", "supercar");
    if ($conn->connect_error) die("Connexion échouée: " . $conn->connect_error);

    $stmt = $conn->prepare("UPDATE essai SET statut = 'Refusé' WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Demande d'essai refusée.";
    } else {
        $_SESSION['error_message'] = "Erreur lors du refus.";
    }
    $stmt->close();
    $conn->close();
} else {
    $_SESSION['error_message'] = "Requête invalide.";
}
header("Location: dashadmin.php#bookings-section");
exit();
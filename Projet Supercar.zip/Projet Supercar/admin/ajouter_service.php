<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    exit("unauthorized");
}

$conn = new mysqli("localhost", "root", "", "supercar");
if ($conn->connect_error) die("db_error");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'] ?? '';
    $icone = $_POST['icone'] ?? 'fas fa-car'; // icône par défaut
    $description = $_POST['description'] ?? '';
    $lien = $_POST['lien'] ?? '';
    $type = $_POST['type'] ?? 'texte';
    $details = $_POST['details'] ?? '';

    $stmt = $conn->prepare("INSERT INTO services (titre, icone, description, lien, type, details) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $titre, $icone, $description, $lien, $type, $details);

    if ($stmt->execute()) {
        header("Location: services.php?msg=added");
        exit;
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}

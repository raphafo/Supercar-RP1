<?php
session_start(); // Toujours en haut

// Connexion à la base de données (mysqli)
$host = "localhost";
$login = "root";
$pass = "";
$dbname = "supercar";
$conn = new mysqli($host, $login, $pass, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

$message = '';
$messageType = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $marque = trim($_POST['marque'] ?? '');
    $annee = intval($_POST['annee'] ?? 0);
    $prix = floatval($_POST['prix'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $disponible = isset($_POST['disponible']) ? 1 : 0;
    
    // Validation des champs
    if (empty($marque) || $annee <= 1900 || $prix <= 0) {
        $message = 'Les champs marque, année et prix sont obligatoires et doivent être valides.';
        $messageType = 'error';
    } elseif ($annee > date('Y') + 1) {
        $message = 'L\'année ne peut pas être supérieure à ' . (date('Y') + 1) . '.';
        $messageType = 'error';
    } elseif ($prix > 10000000) {
        $message = 'Le prix semble trop élevé.';
        $messageType = 'error';
    } else {
        // Gestion de l'upload d'image
        $image_path = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
            $upload_dir = '../images/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($file_extension, $allowed_extensions)) {
                $image_name = uniqid() . '.' . $file_extension;
                $image_path = 'images/' . $image_name; // Chemin enregistré dans la base
                
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $image_name)) {
                    $image_path = null;
                }
            }
        }
        
        // Insérer la nouvelle voiture
        $stmt = $conn->prepare("INSERT INTO voitures (marque, annee, prix, description, image, disponible) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sidssi", $marque, $annee, $prix, $description, $image_path, $disponible);
            
        if ($stmt->execute()) {
            $_SESSION['success_message'] = 'Voiture ajoutée avec succès !';
            header('Location: dashadmin.php');
            exit;
        } else {
            $message = 'Erreur lors de l\'ajout de la voiture : ' . $conn->error;
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Voiture - SuperCar Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .card-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .card-header p {
            opacity: 0.9;
            font-size: 1.1rem;
        }

        .card-body {
            padding: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 0.95rem;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #28a745;
            box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
        }

        .form-group textarea {
            height: 100px;
            resize: vertical;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            margin: 0;
            transform: scale(1.2);
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-right: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-row-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
        }

        @media (max-width: 768px) {
            .form-row,
            .form-row-3 {
                grid-template-columns: 1fr;
            }
            
            .container {
                margin: 20px auto;
                padding: 0 15px;
            }
            
            .card-body {
                padding: 25px;
            }
        }

        .required {
            color: #dc3545;
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #28a745;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 20px;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #20c997;
        }

        .file-input-wrapper {
            position: relative;
            display: inline-block;
            width: 100%;
        }

        .file-input {
            width: 100%;
            padding: 12px 15px;
            border: 2px dashed #e1e5e9;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: border-color 0.3s ease;
        }

        .file-input:hover {
            border-color: #28a745;
        }

        .price-input {
            position: relative;
        }

        .price-input::after {
            content: '€';
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashadmin.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
            Retour au tableau de bord
        </a>

        <div class="card">
            <div class="card-header">
                <h1><i class="fas fa-car-side"></i> Ajouter une Voiture</h1>
                <p>Ajouter un nouveau véhicule à votre inventaire SuperCar</p>
            </div>

            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType == 'error' ? 'error' : 'success' ?>">
                        <i class="fas fa-<?= $messageType == 'error' ? 'exclamation-triangle' : 'check-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="marque">
                                Marque <span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="marque" 
                                   name="marque" 
                                   value="<?= htmlspecialchars($_POST['marque'] ?? '') ?>" 
                                   required
                                   placeholder="Ex: BMW, Mercedes, Audi...">
                        </div>

                    <div class="form-row-3">
                        <div class="form-group">
                            <label for="annee">
                                Année <span class="required">*</span>
                            </label>
                            <input type="number" 
                                   id="annee" 
                                   name="annee" 
                                   value="<?= htmlspecialchars($_POST['annee'] ?? date('Y')) ?>" 
                                   required
                                   min="1950"
                                   max="<?= date('Y') + 1 ?>">
                        </div>

                        <div class="form-group">
                            <label for="prix">
                                Prix <span class="required">*</span>
                            </label>
                            <div class="price-input">
                                <input type="number" 
                                       id="prix" 
                                       name="prix" 
                                       value="<?= htmlspecialchars($_POST['prix'] ?? '') ?>" 
                                       required
                                       min="0"
                                       step="0.01"
                                       placeholder="50000">
                            </div>
                        </div>

                    <div class="form-group">
                        <label for="description">
                            Description
                        </label>
                        <textarea id="description" 
                                  name="description" 
                                  placeholder="Description détaillée de la voiture, équipements, état, etc."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="image">
                            Image de la voiture
                        </label>
                        <div class="file-input-wrapper">
                            <input type="file" 
                                   id="image" 
                                   name="image" 
                                   accept="image/*"
                                   class="file-input">
                        </div>
                        <small style="color: #666; font-size: 0.85rem; margin-top: 5px; display: block;">
                            Formats acceptés: JPG, JPEG, PNG, WEBP (max 5MB)
                        </small>
                    </div>

                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" 
                                   id="disponible" 
                                   name="disponible" 
                                   <?= isset($_POST['disponible']) ? 'checked' : 'checked' ?>>
                            <label for="disponible">Voiture disponible à la vente</label>
                        </div>
                    </div>

                    <div style="margin-top: 30px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            Ajouter la voiture
                        </button>
                        
                        <a href="admin.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i>
                            Annuler
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Validation côté client
        document.querySelector('form').addEventListener('submit', function(e) {
            const prix = parseFloat(document.getElementById('prix').value);
            const annee = parseInt(document.getElementById('annee').value);
            const currentYear = new Date().getFullYear();
            
            if (prix <= 0) {
                e.preventDefault();
                alert('Le prix doit être supérieur à 0.');
                return;
            }
            
            if (annee < 1950 || annee > currentYear + 1) {
                e.preventDefault();
                alert('L\'année doit être comprise entre 1950 et ' + (currentYear + 1) + '.');
                return;
            }
        });

        // Preview de l'image
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                if (file.size > 5 * 1024 * 1024) {
                    alert('Le fichier est trop volumineux (max 5MB).');
                    this.value = '';
                    return;
                }
                
                // Optionnel: prévisualisation de l'image
                const reader = new FileReader();
                reader.onload = function(e) {
                    // Vous pouvez ajouter une prévisualisation ici
                };
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>
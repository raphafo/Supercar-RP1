<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "supercar");
if ($conn->connect_error) die("Erreur connexion DB");

// Récupération d’un service par ID (pour AJAX)
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $res = $conn->query("SELECT * FROM services WHERE id=$id");
    echo json_encode($res->fetch_assoc());
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin SuperCar - Gestion des Services</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #247eec;
            --secondary: #12906c;
            --dark: #343a40;
            --light: #f8f9fa;
        }
        body {
            background-color: #f5f7f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            background: var(--dark);
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 15px 20px;
            display: block;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .sidebar a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        .card-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-radius: 10px 10px 0 0 !important;
            font-weight: 600;
        }
        .btn-primary {
            background: var(--primary);
            border: none;
        }
        .btn-primary:hover {
            background: #1c6bc9;
        }
        .btn-success {
            background: var(--secondary);
            border: none;
        }
        .btn-success:hover {
            background: #0e7a5d;
        }
        .service-card {
            transition: transform 0.3s;
        }
        .service-card:hover {
            transform: translateY(-5px);
        }
        .service-icon {
            font-size: 2rem;
            color: var(--primary);
        }
        .image-preview {
            width: 100px;
            height: 70px;
            object-fit: cover;
            border-radius: 5px;
            margin-right: 5px;
            margin-bottom: 5px;
        }
        .navbar-brand {
            font-weight: 700;
            color: var(--primary);
        }
        .action-buttons .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
        }
        .badge-service {
            background: var(--secondary);
            color: white;
        }
        .table th {
            background-color: var(--primary);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar d-none d-md-block">
                <h4 class="text-center mb-4">Admin SuperCar</h4>
                <a href="services.php"><i class="fas fa-concierge-bell"></i> Aperçu Services</a>
                <a href="maintenance_admin.php"><i class="fas fa-tools"></i> Maintenance</a>
                <a href="accessoires_admin.php"><i class="fas fa-shopping-cart"></i> Accessoires</a>
                <a href="pieces_admin.php"><i class="fas fa-cogs"></i> Pièces</a>
                <a href="conseils_admin.php"><i class="fas fa-users"></i> Conseils</a>

                <a href="dashadmin.php" class="btn-deconnecter">Retour au dashboard</a>
            </div>
        
            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Gestion des Services</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addServiceModal">
                        <i class="fas fa-plus me-2"></i>Ajouter un service
                    </button>
                </div>

            
               <!-- Tableau des services -->
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-list me-2"></i>Liste des services
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Icône</th>
                                <th>Titre</th>
                                <th>Description</th>
                                <th>Type</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $res = $conn->query("SELECT * FROM services ORDER BY id DESC");
                            while ($service = $res->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?= $service['id'] ?></td>
                                    <td><i class="<?= htmlspecialchars($service['icone']) ?> service-icon"></i></td>
                                    <td><?= htmlspecialchars($service['titre']) ?></td>
                                    <td><?= htmlspecialchars($service['description']) ?></td>
                                    <td><span class="badge badge-service"><?= htmlspecialchars($service['type']) ?></span></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#editServiceModal" data-id="<?= $service['id'] ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="supprimer_service.php?id=<?= $service['id'] ?>"
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Confirmer la suppression ?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

                <!-- Modal d'ajout de service -->
                <div class="modal fade" id="addServiceModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Ajouter un nouveau service</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form id="addServiceForm" method="POST" action="ajouter_service.php" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Titre du service</label>
                                                <input type="text" class="form-control" name="titre" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Icône (Bootstrap Icons)</label>
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="bi bi-"></i></span>
                                                    <input type="text" class="form-control" name="icone" placeholder="Ex: tools, cart, gear..." value="tools" required>
                                                </div>
                                                <small class="form-text text-muted">Consultez <a href="https://icons.getbootstrap.com/" target="_blank">Bootstrap Icons</a> pour la liste complète</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea class="form-control" name="description" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Lien</label>
                                    <input type="text" class="form-control" name="lien">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Type</label>
                                    <select class="form-select" name="type">
                                        <option value="galerie">Galerie</option>
                                        <option value="texte">Texte</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Détails</label>
                                    <textarea class="form-control" name="details"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Enregistrer</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

                <!-- Modal d'édition de service -->
                 <!-- Modal d’édition -->
            <div class="modal fade" id="editServiceModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <form id="editServiceForm" method="POST">
                            <div class="modal-header">
                                <h5 class="modal-title">Modifier le service</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" id="serviceId">
                                <div class="mb-3">
                                    <label class="form-label">Titre</label>
                                    <input type="text" class="form-control" name="titre" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Icône (Font Awesome)</label>
                                    <input type="text" class="form-control" name="icone" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea class="form-control" name="description" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Lien</label>
                                    <input type="text" class="form-control" name="lien">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Type</label>
                                    <select class="form-select" name="type">
                                        <option value="galerie">Galerie</option>
                                        <option value="texte">Texte</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Détails</label>
                                    <textarea class="form-control" name="details"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Enregistrer</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
document.addEventListener('DOMContentLoaded', () => {
    // Remplir le formulaire d'édition
    const editServiceModal = document.getElementById('editServiceModal');
    editServiceModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget;
        const serviceId = button.getAttribute('data-id');

        fetch('services.php?id=' + serviceId)
            .then(r => r.json())
            .then(data => {
                document.getElementById('serviceId').value = data.id;
                editServiceModal.querySelector('input[name="titre"]').value = data.titre;
                editServiceModal.querySelector('input[name="icone"]').value = data.icone;
                editServiceModal.querySelector('textarea[name="description"]').value = data.description;
                editServiceModal.querySelector('input[name="lien"]').value = data.lien ?? '';
                editServiceModal.querySelector('select[name="type"]').value = data.type ?? 'texte';
                editServiceModal.querySelector('textarea[name="details"]').value = data.details ?? '';
            });
    });

    // Soumission du formulaire d'édition en AJAX
    document.getElementById('editServiceForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const data = new FormData(this);

        fetch('modifier_service.php', {
            method: 'POST',
            body: data
        })
        .then(r => r.text())
        .then(result => {
            if (result.trim() === "success") {
                alert("Service modifié avec succès !");
                location.reload();
            } else {
                alert("Erreur lors de la modification : " + result);
            }
        });
    });
});
</script>
</body>
</html>

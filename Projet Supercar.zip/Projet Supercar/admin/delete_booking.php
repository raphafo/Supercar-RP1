<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $id = intval($_POST['booking_id']);
    $conn = new mysqli("localhost", "root", "", "supercar");
    if ($conn->connect_error) die("Erreur connexion DB");
    $conn->query("DELETE FROM essai WHERE id = $id");
    $conn->close();
}
header("Location: dashadmin.php#bookings-section");
exit();
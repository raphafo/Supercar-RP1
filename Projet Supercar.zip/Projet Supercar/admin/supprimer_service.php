<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    exit("unauthorized");
}

$conn = new mysqli("localhost", "root", "", "supercar");
if ($conn->connect_error) die("db_error");

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("DELETE FROM services WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: services.php?msg=deleted");
        exit;
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}

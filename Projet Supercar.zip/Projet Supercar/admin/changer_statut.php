<?php
session_start();
if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    header("Location: ../connexion.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_essai'], $_POST['statut_actuel'])) {
    $id = intval($_POST['id_essai']);
    $statut = $_POST['statut_actuel'];

    if ($statut === 'En cours') {
        $conn = new mysqli("localhost", "root", "", "supercar");
        if ($conn->connect_error) die("Connexion échouée: " . $conn->connect_error);

        $stmt = $conn->prepare("UPDATE essai SET statut = 'Terminé' WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Statut passé à Terminé.";
        } else {
            $_SESSION['error_message'] = "Erreur lors du changement de statut.";
        }
        $stmt->close();
        $conn->close();
    }
}
header("Location: dashadmin.php#bookings-section");
exit();
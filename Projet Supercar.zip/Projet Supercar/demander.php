<?php
$host = "localhost";
$login = "root";
$pass = "";
$bdd = "supercar";

$conn = mysqli_connect($host, $login, $pass, $bdd);
if (!$conn) {
    die("Échec de la connexion : " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST["nom"] ?? null;
    $prenom = $_POST["prenom"] ?? null;
    $email= $_POST["email"] ?? null;
    $lieurecup = $_POST["lieurecup"] ?? null;
    $lieudepot = $_POST["lieudepot"] ?? null;
    $daterecup = $_POST["daterecup"] ?? null;
    $datedepot = $_POST["datedepot"] ?? null;
    $heurerecup = $_POST["heurerecup"] ?? null;

    if (!$nom || !$prenom || !$email) {
        die("Erreur : tous les champs requis ne sont pas remplis !");
    }

    // Insérer dans la base de données
    $demande = "INSERT INTO essai (nom, prenom, email,lieurecup, lieudepot, daterecup, datedepot, heurerecup) 
                 VALUES ('$nom', '$prenom', '$email', '$lieurecup', '$lieudepot', '$daterecup', '$datedepot', '$heurerecup')";

    if (mysqli_query($conn, $demande)) {
        echo "Demande enregistrée avec succès !";
        echo " <a href='index.html'>Retour à la page d'accueil </a>";
    } else {
        echo "Erreur SQL : " . mysqli_error($conn);
    }
} else {
    echo "Accès interdit.";
}


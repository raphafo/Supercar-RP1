<?php
// Définir le type de contenu JSON
header('Content-Type: application/json');

// Paramètres de connexion
$host = "localhost";
$dbname = "supercar";
$username = "root";
$password = "";

try {
    // Connexion à la base de données avec PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Nombre de voitures par page
    $limit = 6;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // Requête pour récupérer les voitures
    $stmt = $pdo->prepare("SELECT * FROM voitures LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Requête pour le nombre total de voitures
    $totalStmt = $pdo->query("SELECT COUNT(*) AS total FROM voitures");
    $totalCars = $totalStmt->fetch(PDO::FETCH_ASSOC)['total'];
    $totalPages = ceil($totalCars / $limit);

    // Réponse JSON
    echo json_encode([
        'cars' => $cars,
        'totalPages' => $totalPages
    ]);
} catch (PDOException $e) {
    echo json_encode(['error' => "Erreur de connexion : " . $e->getMessage()]);
}
?>

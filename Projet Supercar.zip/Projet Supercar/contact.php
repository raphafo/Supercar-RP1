<?php
session_start();

$host = "localhost";
$login = "root";
$pass = "";
$bdd = "supercar";

// Connexion
$conn = new mysqli($host, $login, $pass, $bdd);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = htmlspecialchars(trim($_POST["nom"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $sujet = htmlspecialchars(trim($_POST["sujet"]));
    $message = htmlspecialchars(trim($_POST["message"]));

    // Vérifie que nom et email sont présents
    if (empty($nom) || empty($email)) {
        die("Erreur : nom et email sont obligatoires !");
    }

    // Vérifier si la colonne date_envoi existe
    $check_column = $conn->query("SHOW COLUMNS FROM contactez LIKE 'date_envoi'");
    if ($check_column->num_rows == 0) {
        // Ajouter la colonne si elle n'existe pas
        $conn->query("ALTER TABLE contactez ADD date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP");
    }

    // Préparation de la requête SQL sécurisée
    $stmt = $conn->prepare("INSERT INTO contactez (nom, email, sujet, message, date_envoi) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssss", $nom, $email, $sujet, $message);

    if ($stmt->execute()) {
        $_SESSION['message_envoye'] = true;
        echo "Message envoyé avec succès !";
    } else {
        echo "Erreur lors de l'envoi : " . $stmt->error;
    }

    $stmt->close();
}
?>